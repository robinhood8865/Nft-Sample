/* eslint-disable react/react-in-jsx-scope */
import ExploreItems from './components/exploreItems/ExploreItems';

const explore = () => {
  return (
    <div>
      <ExploreItems />
    </div>
  );
};
export default explore;
