- user profile - toggle and group by collection
- close future

bid should be higher from the last bid in some percentage amount
