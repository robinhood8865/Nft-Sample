####

truffle compile truffle migrate --reset --network rinkeby

s

####

deploy to heroku git push heroku main

deploy branch to heroku git push heroku branchName:main

###

run the project npm run dev

### when

hint: Updates were rejected because the tip of your current branch is behind

git push -f heroku main
