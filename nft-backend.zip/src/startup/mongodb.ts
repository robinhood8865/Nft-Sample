/* eslint-disable indent */
import mongoose from 'mongoose';
import winston from 'winston'; // logging package
import config from 'config';
import logger from '../utils/logger';

require('../components/priceTokens/priceTokenDal');

export default function (): void {
  const db = process.env.DB || (config.get('db') as string);
  console.log('🚀 ~ file: mongodb.ts ~ line 9 ~ db', db);

  mongoose
    .connect(db, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
      winston.info('Connected to MongoDB');
      logger.info(`Connected to ${db}`);
    })
    .catch((err) => {
      logger.error(err);
      logger.info('maybe you are not connected to the internet...?');
    });
}
