import express from 'express';
import morgan from 'morgan';
import logger from './../utils/logger';

export default function (app: express.Application) {
  if (app.get('env') === 'development') {

    app.use(morgan('tiny'));
    logger.info('morgan enabled...');
  }
}
