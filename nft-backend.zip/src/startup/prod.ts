import express, { Request, Response } from 'express';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan'; // routes logs

export default function (app: express.Application): void {
  app.use(helmet());
  app.use(compression());
  app.use(morgan('tiny', {
    // do not log requests with status code less then 400
    skip: (req: Request, res: Response): boolean => res.statusCode < 400,
  }));
}
