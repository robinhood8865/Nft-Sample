import express from 'express';
import cors from 'cors'; // for the browser
import error from '../middleware/error';
import v1_routes from './v1routes';
// import v2 from './v2routes';
// eslint-disable-next-line @typescript-eslint/no-var-requires

export default function (app: express.Application): void {

  app.use(cors());
  app.use(express.json()); // json to object

  app.use('/v1', v1_routes);
  // app.use('/v2', v2); // in case of version 2

  app.use(error);
}
