import express, { Request, Response } from 'express';

import authAPI from '../components/auth/v1/authAPI_v1';
import usersAPI from '../components/users/v1/usersAPI_v1';
import nftAPI from '../components/nfts/v1/nftAPI_v1';
import bidsAPI from '../components/bids/v1/bidsAPI_v1';
import collectionsAPI from '../components/collections/v1/collectionsAPI_v1';
import processTrackingAPI from '../components/processTracking/v1/processTrackingAPI_v1';
import eventAPI from '../components/events/v1/eventsAPI_v1';
import searchAPI from '../components/search/v1/searchAPI_v1';
import priceTokensAPI from '../components/priceTokens/v1/priceTokensAPI_v1';

const router = express.Router();

router.use('/auth', authAPI);
router.use('/users', usersAPI);

router.use('/nfts', nftAPI);
router.use('/bids', bidsAPI);
router.use('/collections', collectionsAPI);
router.use('/processTracking', processTrackingAPI);
router.use('/events', eventAPI);
router.use('/search', searchAPI);
router.use('/pricetokens', priceTokensAPI);

router.use('/healtz', (req: Request, res: Response): void => {
  res.send('ok');
});

export default router;
