// import Web3 from 'web3';
// import Provider from '@truffle/hdwallet-provider';
// import config from 'config';
// import { getNetworkData } from "./utils";
// // contracts
// // import NFTMadrket from '../abis/ass';
// // const NFT = require('../abis/NFT.json');
// // const NFTMarket = require('../abis/NFTMarket.json');

// // @ts-ignore
// import NFT from '../abis/NFT.json';
// //@ts-ignore
// import NFTMarket from '../abis/NFTMarket.json';
// //@ts-ignore
// // import Escrow from '../abis/Escrow.json';

// export let web3: any;
// export let nftContract: any;
// export let nftMarketContract: any;
// // export let escrowContract: any;
// // export const owner = '0x22F79d3E5b8e83c03Bb496E48970F255280b886c';

// // const escort_private_key = process.env.escort_private_key || config.get('escort_private_key') as string;
// // const owner_private_key = process.env.wallet_private_key || config.get('wallet_private_key') as string;
// const owner_private_key = '21a2360b561fbfeebdd5b012e48a9e16e473ec931406abd05d26b5dae840c2e6';
// // const infuraId = process.env.infuraId || config.get('infuraId') as string;
// const infuraId = '3d3184cc421046c8b638d184e8fbe107';

// const getMyBalance = async () => {
//   const wei_balance = await web3.eth.getBalance('0x688F231732bde13c3FC572e5f4AcfBA3381b76Da');
//   const eth_balance = await web3.utils.fromWei(wei_balance, "ether");
//   console.log('eth_balance', eth_balance);

//   return eth_balance;
// };

// const getAccounts = async () => {
//   const accounts = await web3.eth.getAccounts();
//   console.log('accounts', accounts);
// };

// export const init3 = async () => {
//   console.log('---init3---');
//   const provider = new Provider(owner_private_key, `https://rinkeby.infura.io/v3/${infuraId}`);
//   web3 = new Web3(provider);
//   const networkId = await web3.eth.net.getId();
//   const networkType = await web3.eth.net.getNetworkType();
//   console.log('networkId', networkId);
//   console.log('networkType', networkType);

//   const NFT_NETWORK_DATA = await getNetworkData(web3, NFT);
//   const NFT_MARKET_NETWORK_DATA = await getNetworkData(web3, NFTMarket);
//   // const ESCROW_MARKET_NETWORK_DATA = await getNetworkData(web3, Escrow);

//   // console.log('NFT_NETWORK_DATA', NFT_NETWORK_DATA);
//   console.log('NFT_MARKET_NETWORK_DATA', NFT_MARKET_NETWORK_DATA);

//   nftContract = new web3.eth.Contract(NFT.abi, NFT_NETWORK_DATA.address);
//   nftMarketContract = new web3.eth.Contract(NFTMarket.abi, NFT_MARKET_NETWORK_DATA.address);

//   nftMarketContract.events.SimpleMarketItemCreated({ fromBlock: 0 })
//     .on('data', (event: any) => {
//       console.log('SimpleMarketItemCreated');
//       console.log(event);
//     },
//     );
//   // getMyBalance();
//   getAccounts();
// };
