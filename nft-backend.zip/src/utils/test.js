// const arr = [1, 2, 3, 4, 5, 6]

// const newArr = arr.slice(1, arr.length - 1)
// console.log(arr.slice(1, arr.length - 1));

const today = new Date();
const exp = new Date('2022-01-11T00:00:00.000+00:00');

console.log('🚀 ~ file: test.js ~ line 10 ~ today > exp', today > exp);
