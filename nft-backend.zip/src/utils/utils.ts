import { ISimpleMarketItem } from './enums';

export const getUserNftQuantityFromNftContract = async (data: {
  nftContract: any;
  userAddress: string;
  tokenId: number;
}): Promise<string> => {
  const { nftContract, userAddress, tokenId } = data;
  const balance = await nftContract.methods.balanceOf(userAddress, tokenId).call();
  return balance;
};

export const getSimpleMarketItem = async (data: {
  nftMarketSimpleContract: any;
  listingId: any;
}): Promise<ISimpleMarketItem> => {
  const { nftMarketSimpleContract, listingId } = data;
  const marketItem = await nftMarketSimpleContract.methods.simpleListingIdToMarketItem(Number(listingId)).call();
  return marketItem;
};
