const ErrorTypes = {
  VALUES_NOT_VALID: 'ERR001',
  SMS_CODE_NOT_VALID: 'ERR002',
  HOSPITALIZATION_CASE_NOT_EXISTS: 'ERR003',
  ERROR_IN_SCHEDULES: 'ERR004',
  ERROR_IN_PATIENTS: 'ERR005',
  NETWORK_ERROR: 'ERR006',
  NOT_ALLOWED: 'ERR007',
};

class GeneralError extends Error {
  constructor(message: string) {
    super();
    this.message = message;
  }

  getCode() {
    if (Object.keys(ErrorTypes).includes(this.message)) {
      return this.message;
    }
    if (this instanceof BadRequest) {
      return 400;
    }
    if (this instanceof NotFound) {
      return 404;
    }
    return 500;
  }
}

class BadRequest extends GeneralError {}
class NotFound extends GeneralError {}

export { GeneralError, BadRequest, NotFound, ErrorTypes };
