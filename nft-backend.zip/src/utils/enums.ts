export enum MARKET_TYPE {
  SIMPLE = 'SIMPLE',
  AUCTION = 'AUCTION',
  MORE = 'MORE',
}

export enum ITEM_TYPE {
  single_items = 'single_items',
  bundles = 'bundles',
}

export enum STATUS {
  ON_SELL = 'ON_SELL', //TODO: CHANGE TO ===>> ON_SALE
  NOT_LISTED = 'NOT_LISTED',
}

export enum IMAGES_NAMES {
  PROFILE_IMAGE = 'PROFILE_IMAGE',
}

export enum PROCESS_TRAKING_ACTION {
  CREATE_SIMPLE_SINGLE = 'CREATE_SIMPLE_SINGLE',
  CREATE_SIMPLE_MULTIPLE = 'CREATE_SIMPLE_MULTIPLE',
  CREATE_AUCTION = 'CREATE_AUCTION',
  LIST_SIMPLE_SINGLE = 'LIST_SIMPLE_SINGLE',
  LIST_SIMPLE_MULTIPLE = 'LIST_SIMPLE_MULTIPLE',
  LIST_AUCTION = 'LIST_AUCTION',
  CANCEL_SIMPLE_SINGLE = 'CANCEL_SIMPLE_SINGLE',
  CANCEL_SIMPLE_MULTIPLE = 'CANCEL_SIMPLE_MULTIPLE',
  CANCEL_AUCTION = 'CANCEL_AUCTION',
  BUY_SIMPLE_SINGLE = 'BUY_SIMPLE_SINGLE',
  BUY_SIMPLE_MULTIPLE = 'BUY_SIMPLE_MULTIPLE',
  BID = 'BID',
  TERMINATE_AUCTION_NOT_SOLD = 'TERMINATE_AUCTION_NOT_SOLD',
  TERMINATE_AUCTION_SOLD = 'TERMINATE_AUCTION_SOLD',
}

export enum PROCESS_TRAKING_STATUS {
  BEFORE = 'BEFORE',
  AFTER = 'AFTER',
}

export enum SORT_ORDER {
  RECENTLY_ADDED = 'recently added',
  PRICE_LOW_TO_HIGH = 'price low to high',
  PRICE_HIGH_TO_LOW = 'price high to low',
  AUCTION_ENDING_SOON = 'auction ending soon',
}

export enum DEFAULT_TIMEFRAME {
  THIRTY = 30,
}

export enum MARKET_CONTRACT_EVENTS {
  Mint = 'Mint',
  SimpleMarketItemCreated = 'SimpleMarketItemCreated',
  AuctionMarketItemCreated = 'AuctionMarketItemCreated',
  SimpleItemSoldEvent = 'SimpleItemSold',
  BidCreated = 'BidCreated',
  SimpleItemCancelled = 'SimpleItemCancelled',
  AuctionCancelled = 'AuctionCancelled',
  TerminateAuctionEvent = 'TerminateAuctionEvent',
  SimpleItemCreated = 'SimpleItemCreated',
  AuctionItemCreated = 'AuctionItemCreated',
  AuctionBidCreated = 'AuctionBidCreated',
}
export interface ISimpleMarketItem {
  nftContract: string;
  nftTokenId: string;
  price: string;
  originalQuantity: string;
  remainingQuantity: string;
  ownerAddress: string;
  deadline: string;
}

export interface IAuctionMarketItem {
  nftContract: string;
  tokenId: string;
  startPrice: string;
  currentBid: string;
  currentBidderAddress: string;
  ownerAddress: string;
  deadline: string;
  isClosed: boolean;
}

export const ONE_DAY = 24 * 60 * 60 * 1000;

export enum ERRORS {
  TOKEN_EXPIRED = 'Token is expired.',
  TOKEN_INVALID = 'Token is invalid.',
  NO_TOKEN = 'Access denied. No token provided.',
  INVALID_REQUEST = 'Invalid Request',
}

export enum TOKEN_LIFE {
  ACCESS_TOKEN = 60,
  REFRESH_TOKEN = 86400,
}
