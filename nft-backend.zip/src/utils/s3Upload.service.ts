/* eslint-disable indent */
import AWS from 'aws-sdk';
import moment from 'moment';
import { v4 as uuidv4 } from 'uuid';
import config from 'config';
import logger from './logger';
import { IMAGES_NAMES } from '../utils/enums';

const AWS_S3_BUCKET_NAME = process.env.AWS_S3_BUCKET_NAME || config.get('AWS_S3_BUCKET_NAME');
const ACCESS_KEY = process.env.ACCESS_KEY || config.get('ACCESS_KEY');
const SECRET_KEY = process.env.SECRET_KEY || config.get('SECRET_KEY');
// const AWS_S3_BUCKET_NAME_PRIVATE = process.env.AWS_S3_BUCKET_NAME_PRIVATE || config.get('AWS_S3_BUCKET_NAME_PRIVATE');

// const SERVER_URL = process.env.SERVER_URL || config.get('SERVER_URL');


const s3 = new AWS.S3({
    accessKeyId: ACCESS_KEY,
    secretAccessKey: SECRET_KEY,
});

const saveImage = (file: any, imageTitle: IMAGES_NAMES): string => {
    if (!file) {
        return '';
    }
    const isPublicImage = [IMAGES_NAMES.PROFILE_IMAGE].includes(imageTitle);

    const BUCKET = isPublicImage ? `${AWS_S3_BUCKET_NAME}/static` : 'AWS_S3_BUCKET_NAME_PRIVATE';
    const imageRemoteName = `${imageTitle ? `${imageTitle}_` : ''}_${moment(new Date()).format('DD-MM-YYYY-HH-mm-ss')}-${uuidv4()}_${file.originalname}`;
    const params: any = {
        Bucket: BUCKET,
        Key: imageRemoteName, // File name you want to save as in S3
        Body: file.buffer, // fs.readFileSync(localImage),
        ContentType: 'image/jpeg',
    };

    s3.upload(params, function (err: any, data: any) {
        if (err) {
            logger.error(`error in s3upload`);
            logger.error('err', err);

            throw err;
        }
        logger.info(`File uploaded successfully. ${data.Location}`);
    });

    return imageRemoteName;
};


// const getSignedUrl = (imageRemoteName: string): string | undefined => {
//     if (imageRemoteName) {
//         return s3.getSignedUrl('getObject', { Bucket: AWS_S3_BUCKET_NAME_PRIVATE, Key: imageRemoteName });
//     }
// };

const getPublicImageLink = (imageName: string): string => {
    return `https://nop-profiles.s3.us-east-2.amazonaws.com/static/${imageName}`;
};

// const getUserAvatarUrl = (avatar: string): string | undefined => {
//     if (!avatar) return '';
//     return getSignedUrl(avatar); // s3 bucket image profile
// };

const s3Upload = {
    saveImage,
    // getSignedUrl,
    // getUserAvatarUrl,
    getPublicImageLink,
};

export default s3Upload;