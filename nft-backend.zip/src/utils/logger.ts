import config from 'config';
import { createLogger, transports, format } from 'winston'; // logging package
import 'winston-mongodb';

// export default (...log: any) => {
//   if (config.get('env') === 'development') {
//     console.log(...log);
//   }
// };

const db = process.env.DB || config.get('db') as string;

const logger = createLogger({
  transports: [
    new transports.Console({
      level: 'info',
      format: format.combine(format.timestamp(), format.simple()),
    }),
    // new transports.File({
    //   filename: 'info.log',
    //   level: 'info',
    //   format: format.combine(format.timestamp(), format.simple()),
    // }),
    new transports.MongoDB({
      db,
      level: 'error',
      collection: 'log',
      options: {
        useUnifiedTopology: true,
      },
      // format: format.combine(format.timestamp(), format.json()),
    }),
  ],
});

export default logger;