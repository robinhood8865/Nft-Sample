/* eslint-disable @typescript-eslint/no-var-requires */
import { MARKET_CONTRACT_EVENTS } from './enums';
import { bidCreatedEvent } from './events/bidCreatedEvent';
import { nftMintedEvent } from './events/nftMintedEvent';
import { buySimpleEvent } from './events/buySimpleEvent';
import { cancelSimpleEvent } from './events/cancelSimpleEvent';
import { simpleMarketItemCreatedEvent } from './events/simpleMarketItemCreatedEvent';
import { auctionItemCreatedEvent } from './events/auctionMarketItemCreatedEvent';
import { cancelAuctionEvent } from './events/cancelAuctionEvent';
import { terminateAuctionEvent } from './events/terminateAuctionEvent';

const Web3 = require('web3');
//* new NFT contract
const nft721 = require('../abis/new/NFT721.json');
const nft721ABI = require('../abis/new/NFT721.json').abi;
const nft1155 = require('../abis/new/NFT1155.json');
const nft1155ABI = require('../abis/new/NFT1155.json').abi;
//* nft market contract
const nftMarketSimple = require('../abis/new/NFTMarketSimple.json');
const nftMarketSimpleABI = require('../abis/new/NFTMarketSimple.json').abi;
const nftMarketAuction = require('../abis/new/NFTMarketAuction.json');
const nftMarketAuctionABI = require('../abis/new/NFTMarketAuction.json').abi;
//* infuraId
const infuraId = '3d3184cc421046c8b638d184e8fbe107';

type EventHandler = (event: any) => void;
type _Object = { [key: string]: any };

export const nft721ContractAddress = nft721.networks[5].address;
export const nft1155ContractAddress = nft1155.networks[5].address;

// console.log(nft721ContractAddress, nft1155ContractAddress);
export const init31 = async () => {
  const options = {
    // Enable auto reconnection
    reconnect: {
      auto: true,
      delay: 5000, // ms
      maxAttempts: 10000,
      onTimeout: false,
    },
  };

  // const url = `wss://rinkeby.infura.io/ws/v3/${infuraId}`;
  // const url = 'wss://eth-rinkeby.alchemyapi.io/v2/oLk9S-P08Qx5pGeAda8t5IpyKrXjOdlV';
  const url = 'wss://eth-goerli.g.alchemy.com/v2/W5tdPodBbYuTBUPD52wUATwe1JFHIdXc';
  let provider = new Web3.providers.WebsocketProvider(url, options);
  const web3 = new Web3(provider);

  //* nft contract
  const nft721Contract = new web3.eth.Contract(nft721ABI, nft721ContractAddress);
  const nft1155Contract = new web3.eth.Contract(nft1155ABI, nft1155ContractAddress);

  //* nft market contract
  const nftMarketSimpleContract = new web3.eth.Contract(nftMarketSimpleABI, nftMarketSimple.networks[5].address);
  const nftMarketAuctionContract = new web3.eth.Contract(nftMarketAuctionABI, nftMarketAuction.networks[5].address);

  const networkId = await web3.eth.net.getId();
  console.log('🚀 ~ file: web31.ts ~ line 64 ~ init31 ~ networkId', networkId);

  provider.on('error', (e: any) => console.log('WS Error', e));
  provider.on('end', (e: any) => {
    console.log('WS closed', e);
    console.log('Attempting to reconnect...');
    provider = new Web3.providers.WebsocketProvider(url);

    provider.on('connect', function () {
      console.log('WSS Reconnected');
    });

    web3.setProvider(provider);
  });

  const subscribeLogEvent = (contract: any, eventName: string, onSuccess: EventHandler) => {
    try {
      //* getting the values that connected to the event
      const foundValue = contract._jsonInterface.find((o: any) => {
        return o.name === eventName && o.type === 'event';
      });

      if (!foundValue) {
        console.log('No event with this name');

        return;
      }
      // console.log('contract._jsonInterface', contract._jsonInterface);

      // console.log('eventName=>', eventName);
      // console.log('foundValue=>', foundValue)
      // //* signature
      // console.log('foundValue.signature=>', foundValue.signature);
      // console.log('address=>', contract.options.address)

      web3.eth.subscribe(
        'logs',
        {
          address: contract.options.address,
          topics: [foundValue.signature],
        },
        (error: any, result: any) => {
          try {
            const { transactionHash } = result;
            // console.log('result&&', result);

            if (!error) {
              const { transactionHash } = result;
              const eventObj = web3.eth.abi.decodeLog(foundValue.inputs, result.data, result.topics.slice(1));
              // console.log('eventObj==>', eventObj);

              onSuccess({ ...eventObj, transactionHash, networkId, web3 });
            }
          } catch (e) {
            console.log('emCollectionFactory-subscription-error', e);
          }
        },
      );
    } catch (e) {
      console.log('emCollectionFactory-subscribeLogEvent-error', e);
    }
  };

  //** event --- mint nft */
  subscribeLogEvent(nft721Contract, MARKET_CONTRACT_EVENTS.Mint, async (event) => {
    console.log('---------------------NFT721 event occured---------------------');
    nftMintedEvent({
      event,
      eventName: MARKET_CONTRACT_EVENTS.Mint,
      web3,
      networkId,
      nftAddress: nft721.networks[5].address,
    });
  });

  subscribeLogEvent(nft1155Contract, MARKET_CONTRACT_EVENTS.Mint, async (event) => {
    console.log('---------------------NFT1155 event occured---------------------');
    nftMintedEvent({
      event,
      eventName: MARKET_CONTRACT_EVENTS.Mint,
      web3,
      networkId,
      nftAddress: nft1155.networks[5].address,
    });
  });

  //* AuctionMarketItemCreated
  subscribeLogEvent(nftMarketAuctionContract, MARKET_CONTRACT_EVENTS.AuctionItemCreated, (event) => {
    console.log('auction market item created event occured');
    auctionItemCreatedEvent({ event, eventName: MARKET_CONTRACT_EVENTS.AuctionItemCreated, web3, networkId });
  });

  //** event --- create bid */
  subscribeLogEvent(nftMarketAuctionContract, MARKET_CONTRACT_EVENTS.AuctionBidCreated, async (event) => {
    bidCreatedEvent({
      nftMarketAuctionContract,
      event,
      eventName: MARKET_CONTRACT_EVENTS.AuctionBidCreated,
      web3,
      networkId,
    });
  });

  // ** event --- SimpleMarketItemCreated */
  subscribeLogEvent(nftMarketSimpleContract, MARKET_CONTRACT_EVENTS.SimpleItemCreated, (event) => {
    console.log('---------------------Simple Item Created event occured---------------------');
    simpleMarketItemCreatedEvent({
      nftMarketSimpleContract,
      event,
      eventName: MARKET_CONTRACT_EVENTS.SimpleItemCreated,
      web3,
      networkId,
    });
  });

  //* BuySimple Event
  subscribeLogEvent(nftMarketSimpleContract, MARKET_CONTRACT_EVENTS.SimpleItemSoldEvent, (event) => {
    buySimpleEvent({
      nftMarketSimpleContract,
      event,
      eventName: MARKET_CONTRACT_EVENTS.SimpleItemSoldEvent,
      web3,
      networkId,
    });
  });

  //* CancelSimple Event
  subscribeLogEvent(nftMarketSimpleContract, MARKET_CONTRACT_EVENTS.SimpleItemCancelled, (event) => {
    cancelSimpleEvent({
      nftMarketSimpleContract,
      event,
      eventName: MARKET_CONTRACT_EVENTS.SimpleItemCancelled,
      web3,
      networkId,
    });
  });

  //* cancel Auction Event
  subscribeLogEvent(nftMarketAuctionContract, MARKET_CONTRACT_EVENTS.AuctionCancelled, (event) => {
    cancelAuctionEvent({
      nftMarketAuctionContract,
      event,
      eventName: MARKET_CONTRACT_EVENTS.AuctionCancelled,
      web3,
      networkId,
    });
  });

  //* cancel Auction Event
  subscribeLogEvent(nftMarketAuctionContract, MARKET_CONTRACT_EVENTS.TerminateAuctionEvent, (event) => {
    terminateAuctionEvent({
      nftMarketAuctionContract,
      event,
      eventName: MARKET_CONTRACT_EVENTS.TerminateAuctionEvent,
      web3,
      networkId,
    });
  });
};
