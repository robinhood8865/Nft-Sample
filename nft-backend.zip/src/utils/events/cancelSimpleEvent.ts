import nftService from '../../components/nfts/v1/nftService_v1';
import processTrackingService from '../../components/processTracking/v1/processTrackingService_v1';
import { MARKET_CONTRACT_EVENTS, MARKET_TYPE, PROCESS_TRAKING_ACTION, PROCESS_TRAKING_STATUS, STATUS } from '../enums';
import { getSimpleMarketItem, getUserNftQuantityFromNftContract } from '../utils';
const eventPool = require('../../components/events/v1/eventService_v1').default;

interface IEvent {
  listingId: string;
  transactionHash: string;
}

interface INftCancelSimpleEvent {
  nftMarketSimpleContract: any;
  event: IEvent;
  eventName: MARKET_CONTRACT_EVENTS;
  web3: any;
  networkId: number;
}

export const cancelSimpleEvent = async (data: INftCancelSimpleEvent) => {
  //* data
  const { nftMarketSimpleContract, event, eventName, networkId } = data;
  console.log('🚀 ~ file: cancelSimpleEvent.ts ~ line 35 ~ cancelSimpleEvent ~ eventName', eventName);
  const { listingId, transactionHash } = event;

  const simpleMarketItem = await getSimpleMarketItem({ nftMarketSimpleContract, listingId });

  const { nftContract, nftTokenId, originalQuantity, remainingQuantity, ownerAddress } = simpleMarketItem;

  //* find on mongo id nft exist, to make sure the it saved only once on the db
  const existedItem = await nftService.getNftByTransactionHash({ transactionHash });

  if (existedItem) {
    console.log('existedItem!!!');
    return;
  }

  const nftdetail = await nftService.getNftDetailesNoPopulate({
    tokenId: nftTokenId,
    nftAddress: nftContract,
    ownerAddress,
  });
  const { name, description, imageUrl, attributes, multiple, collectionId, creatorAddress, royalty, category } =
    nftdetail;

  const _attributes = attributes.map((item: any) => {
    return {
      display_type: item.display_type,
      trait_type: item.trait_type,
      value: item.value,
    };
  });

  const _remainingQuantity = Number(remainingQuantity);
  const _originalQuantity = Number(originalQuantity);

  //** mongo item */
  const nftToCreate: any = {
    listingId,
    tokenId: nftTokenId,
    transactionHash,
    name,
    description,
    imageUrl,
    ownerAddress,
    attributes: _attributes,
    creatorAddress: creatorAddress,
    nftAddress: nftContract,
    collectionId,
    royalty,
    marketType: MARKET_TYPE.SIMPLE,
    status: STATUS.NOT_LISTED,
    multiple,
    networkId,
    category,
    isListedOnce: true,
    totalAmount: _originalQuantity,
    leftAmount: _remainingQuantity,
    listedAmount: 0,
  };

  // * create mongo row
  const nft: any = await nftService.createNft(nftToCreate);

  // ** create proccess tracking */
  await processTrackingService.createTracking({
    ...nftToCreate,
    transactionHash,
    userAddress: ownerAddress,
    networkId,
    action: multiple ? PROCESS_TRAKING_ACTION.CANCEL_SIMPLE_MULTIPLE : PROCESS_TRAKING_ACTION.CANCEL_SIMPLE_SINGLE,
    processStatus: PROCESS_TRAKING_STATUS.AFTER,
  });

  //* fire event
  eventPool.fireEvent({
    eventName,
    ...nft.toObject(),
  });
};
