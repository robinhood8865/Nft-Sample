import nftService from '../../components/nfts/v1/nftService_v1';
import processTrackingService from '../../components/processTracking/v1/processTrackingService_v1';
import { MARKET_CONTRACT_EVENTS, MARKET_TYPE, PROCESS_TRAKING_ACTION, PROCESS_TRAKING_STATUS, STATUS } from '../enums';
import { getSimpleMarketItem } from '../utils';
const eventPool = require('../../components/events/v1/eventService_v1').default;

interface IEvent {
  listingId: string;
  tokenId: string;
  price: number;
  _nftContractAddress: string;
  creatorAddress: string;
  sellerAddress: string;
  buyerAddress: string;
  quantity: number;
  royalty: number;
  frontData: any;
  tokenURI: string;
  transactionHash: string;
}

interface INftBuySimpleEvent {
  nftMarketSimpleContract: any;
  // nftContract: any;
  event: IEvent;
  eventName: MARKET_CONTRACT_EVENTS;
  web3: any;
  networkId: number;
}

export const buySimpleEvent = async (data: INftBuySimpleEvent) => {
  //* data
  const { nftMarketSimpleContract, event, eventName, web3, networkId } = data;
  console.log('🚀 ~ file: buySimpleEvent.ts ~ line 35 ~ buySimpleEvent ~ eventName', eventName);

  const { listingId, quantity, transactionHash } = event;
  console.log('🚀 ~ file: buySimpleEvent.ts ~ line 38 ~ buySimpleEvent ~ event', event);

  const marketitem = await getSimpleMarketItem({ nftMarketSimpleContract, listingId });
  console.log('🚀 ~ file: buySimpleEvent.ts ~ line 38 ~ buySimpleEvent ~ marketitem', marketitem);
  const { nftContract, nftTokenId, price, originalQuantity, remainingQuantity, ownerAddress, deadline } = marketitem;

  const nftdetail = await nftService.getNftDetailesNoPopulate({
    tokenId: nftTokenId,
    nftAddress: nftContract,
  });
  console.log('🚀 ~ file: buySimpleEvent.ts ~ line 47 ~ buySimpleEvent ~ nftdetail', nftdetail);

  //* find on mongo id nft exist, to make sure the it saved only once on the db
  const existedItem = await nftService.getNftByTransactionHash({ transactionHash });
  if (existedItem) {
    console.log('🚀 ~ file: buySimpleEvent.ts ~ line 67 ~ buySimpleEvent ~ existedItem!!!!!');
    return;
  }

  const priceInEth = web3.utils.fromWei(price.toString(), 'ether');

  // * create mongo seller row
  const newone = await nftService.createNft({
    ...nftdetail,
    price: priceInEth,
    ownerAddress,
    status: Number(remainingQuantity) > 0 ? STATUS.ON_SELL : STATUS.NOT_LISTED,
    leftAmount: Number(quantity),
    listedAmount: Number(remainingQuantity),
    totalAmount: Number(quantity) + Number(remainingQuantity),
  });
  console.log('🚀 ~ file: buySimpleEvent.ts ~ line 68 ~ buySimpleEvent ~ newone', newone);

  let _listedAmount = 0;
  const buyerFields = async () => {
    const fields: any = {};
    if (nftdetail.multiple) {
      const nftGroups = await nftService.nftMultipleDetailes({
        tokenId: nftTokenId,
        nftAddress: nftContract.toLowerCase(),
      });
      console.log('🚀 ~ file: buySimpleEvent.ts ~ line 133 ~ buyerFields ~ nftGroups.length', nftGroups.length);
      const buyerCurrentCollectible = nftGroups.find((group) => group.ownerAddress === ownerAddress.toLowerCase());
      console.log(
        '🚀 ~ file: buySimpleEvent.ts ~ line 134 ~ buyerFields ~ buyerCurrentCollectible',
        buyerCurrentCollectible,
      );

      if (buyerCurrentCollectible) {
        _listedAmount = Number(buyerCurrentCollectible.listedAmount);
      }
      fields.status = buyerCurrentCollectible ? buyerCurrentCollectible.status : STATUS.NOT_LISTED;
      fields.price = buyerCurrentCollectible ? buyerCurrentCollectible.price : null;
      fields.listingId = buyerCurrentCollectible ? buyerCurrentCollectible.listingId : null;
    } else {
      fields.status = STATUS.NOT_LISTED;
      fields.price = null;
      fields.listingId = null;
    }
    console.log('🚀 ~ file: buySimpleEvent.ts ~ line 151 ~ buyerFields ~ fields', fields);

    return fields;
  };

  const _buyerFields = await buyerFields();
  // * create mongo buyer row
  const buyerNftResultAfterBuying: any = await nftService.createNft({
    ...nftdetail,
    ownerAddress,
    totalAmount: Number(quantity) + _listedAmount,
    leftAmount: quantity,
    listedAmount: _listedAmount,
    transactionHash,
    ..._buyerFields,
  });

  // ** create proccess tracking */
  await processTrackingService.createTracking({
    ...nftdetail,
    price: priceInEth,
    transactionHash,
    userAddress: ownerAddress,
    networkId,
    action: nftdetail.multiple ? PROCESS_TRAKING_ACTION.BUY_SIMPLE_MULTIPLE : PROCESS_TRAKING_ACTION.BUY_SIMPLE_SINGLE,
    processStatus: PROCESS_TRAKING_STATUS.AFTER,
  });

  //* fire event
  eventPool.fireEvent({
    eventName,
    ...buyerNftResultAfterBuying.toObject(),
  });
};
