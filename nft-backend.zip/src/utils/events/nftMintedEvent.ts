import nftService from "../../components/nfts/v1/nftService_v1";
import processTrackingService from "../../components/processTracking/v1/processTrackingService_v1";
import { MARKET_CONTRACT_EVENTS, PROCESS_TRAKING_ACTION, PROCESS_TRAKING_STATUS, STATUS } from "../enums";
const eventPool = require('../../components/events/v1/eventService_v1').default;

interface IEvent {
  newItemId: string;
  tokenURI: string;
  amount: number;
  royalty: number;
  creator: string;
  startPrice: number;
  deadline: number;
  frontData: any;
  transactionHash: string;
}

interface INftMintedEvent {
  event: IEvent;
  eventName: MARKET_CONTRACT_EVENTS;
  web3: any;
  networkId: number;
  nftAddress: string;
}

export const getImage = (image: string | undefined | null) => {
  const gatewayUrl = 'https://ipfs.nftonpulse.io/ipfs/';
  if (!image) return;
  return image.replace('ipfs://', gatewayUrl);
};

// export const nftMintedEvent = async (data: INftMintedEvent) => {
//   //* data
//   const { event, eventName, web3, networkId, nftAddress } = data;
//   console.log('eventName', eventName);
//   const { newItemId, tokenURI, amount, royalty, creator, startPrice, deadline, frontData, transactionHash } = event;
//   console.log('frontData', frontData);

//   const { name, description, imageUrl, previewImageUrl, attributes, multiple, collectionId, category } = frontData;

//   //* find on mongo id nft exist, to make sure the it saved only once on the db
//   const existedNft = await nftService.getNftByTransactionHash({ transactionHash });

//   if (existedNft) {
//     console.log('existedNft!!!');
//     return;
//   }
//   const _attributes = attributes.map((item: any) => {
//     return {
//       display_type: item.display_type,
//       trait_type: item.trait_type,
//       value: item.value,
//     };
//   });

//   //** mongo item */
//   const nftToCreate: any = {
//     tokenId: newItemId,
//     tokenURI: tokenURI,
//     transactionHash,
//     name: name,
//     description: description,
//     imageUrl: imageUrl,
//     previewImageUrl: previewImageUrl,
//     attributes: _attributes,
//     creatorAddress: creator,
//     ownerAddress: creator,
//     nftAddress,
//     collectionId,
//     royalty,
//     multiple,
//     networkId,
//     category: category,
//     isListedOnce: false,
//     status: STATUS.NOT_LISTED,
//     totalAmount: amount,
//     leftAmount: amount,
//     listedAmount: 0,
//   };

//   // * create mongo row
//   const res: any = await nftService.createNft(nftToCreate);

//   const getAction = () => {
//     if (multiple) {
//       return PROCESS_TRAKING_ACTION.CREATE_SIMPLE_MULTIPLE;
//     }
//     if (startPrice > 0) {
//       return PROCESS_TRAKING_ACTION.CREATE_AUCTION;
//     }
//     return PROCESS_TRAKING_ACTION.CREATE_SIMPLE_SINGLE;
//   };

//   // ** create proccess tracking */
//   await processTrackingService.createTracking({
//     ...nftToCreate,
//     transactionHash,
//     userAddress: creator,
//     networkId,
//     action: getAction(),
//     processStatus: PROCESS_TRAKING_STATUS.AFTER,
//   });

//   //* fire event
//   eventPool.fireEvent({
//     eventName,
//     ...res.toObject(),
//   });
// };

export const nftMintedEvent = async (data: INftMintedEvent) => {
  //* data
  const { event, networkId, nftAddress } = data;
  const { newItemId, transactionHash } = event;
  //* find on mongo id nft exist, to make sure the it saved only once on the db
  const existedNft = await nftService.getNftByTransactionHash({ transactionHash });

  if (existedNft) {
    console.log('existedNft!!!');
    return;
  }

  /** mongo item */
  const nftToCreate: any = {
    tokenId: newItemId,
    transactionHash,
    nftAddress,
    networkId,
    flag: false,
  };

  // * create mongo row
  await nftService.createNft(nftToCreate);
};