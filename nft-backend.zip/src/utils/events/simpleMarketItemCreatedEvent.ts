import nftService from '../../components/nfts/v1/nftService_v1';
import { MARKET_CONTRACT_EVENTS } from '../enums';
import { getSimpleMarketItem } from '../utils';

interface IEvent {
  listingId: string;
  tokenId: string;
  _nftContractAddress: string;
  price: number;
  creatorAddress: string;
  sellerAddress: string;
  quantity: number;
  royalty: number;
  frontData: any;
  tokenURI: string;
  transactionHash: string;
}

interface INftSimpleMarketItemCreatedEvent {
  nftMarketSimpleContract: any;
  event: IEvent;
  eventName: MARKET_CONTRACT_EVENTS;
  web3: any;
  networkId: number;
}

export const getUserNftQuantityFromNftContract = async (data: {
  nftContract: any;
  userAddress: string;
  tokenId: number;
}): Promise<string> => {
  const { nftContract, userAddress, tokenId } = data;
  const balance = await nftContract.methods.balanceOf(userAddress, tokenId).call();
  return balance;
};

export const simpleMarketItemCreatedEvent = async (data: INftSimpleMarketItemCreatedEvent) => {
  //* data
  const { nftMarketSimpleContract, event, networkId } = data;
  const { listingId, transactionHash } = event;
  //* find on mongo id nft exist, to make sure the it saved only once on the db
  const existedItem = await nftService.getNftByTransactionHash({ transactionHash });

  if (existedItem) {
    console.log('existedItem!!!');
    return;
  }

  const marketitem = await getSimpleMarketItem({ nftMarketSimpleContract, listingId });
  //** mongo item */
  const nftToCreate: any = {
    listingId,
    transactionHash,
    nftAddress: marketitem.nftContract,
    networkId,
    flag: false,
  };
  await nftService.createNft(nftToCreate);
};
