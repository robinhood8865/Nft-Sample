import nftService from '../../components/nfts/v1/nftService_v1';
import processTrackingService from '../../components/processTracking/v1/processTrackingService_v1';
import { MARKET_CONTRACT_EVENTS, MARKET_TYPE, PROCESS_TRAKING_ACTION, PROCESS_TRAKING_STATUS, STATUS } from '../enums';
const eventPool = require('../../components/events/v1/eventService_v1').default;

interface IEvent {
  listingId: string;
  tokenURI: string;
  transactionHash: string;
}

interface INftCancelAuctionEvent {
  nftMarketAuctionContract: any;
  event: IEvent;
  eventName: MARKET_CONTRACT_EVENTS;
  web3: any;
  networkId: number;
}

export const getUserNftQuantityFromNftContract = async (data: {
  nftContract: any;
  userAddress: string;
  tokenId: number;
}): Promise<string> => {
  const { nftContract, userAddress, tokenId } = data;
  const balance = await nftContract.methods.balanceOf(userAddress, tokenId).call();
  return balance;
};

export const cancelAuctionEvent = async (data: INftCancelAuctionEvent) => {
  //* data
  const { nftMarketAuctionContract, event, eventName, web3, networkId } = data;
  console.log('🚀 ~ file: cancelAuctionEvent.ts ~ line 39 ~ cancelAuctionEvent ~ eventName', eventName);
  const { listingId, transactionHash } = event;

  //* find on mongo id nft exist, to make sure the it saved only once on the db
  const existedItem = await nftService.getNftByTransactionHash({ transactionHash });

  if (existedItem) {
    console.log('existedItem!!!');
    return;
  }
  const auctionMarketItem = await nftMarketAuctionContract.methods.auctionListingIdToMarketItem(listingId).call();

  const { nftContract, nftTokenId, ownerAddress } = auctionMarketItem;

  const nftdetail = await nftService.getNftDetailesNoPopulate({
    tokenId: nftTokenId,
    nftAddress: nftContract,
    ownerAddress,
  });
  const { name, description, imageUrl, attributes, multiple, collectionId, creatorAddress, royalty, category } =
    nftdetail;

  const _attributes = attributes.map((item: any) => {
    return {
      display_type: item.display_type,
      trait_type: item.trait_type,
      value: item.value,
    };
  });

  //** mongo item */
  const nftToCreate: any = {
    listingId,
    tokenId: nftTokenId,
    transactionHash,
    name,
    description,
    imageUrl,
    ownerAddress,
    attributes: _attributes,
    creatorAddress: creatorAddress,
    collectionId,
    royalty,
    marketType: MARKET_TYPE.AUCTION,
    status: STATUS.NOT_LISTED,
    isListedOnce: true,
    multiple,
    networkId,
    category,
  };

  // * create mongo row
  const nft: any = await nftService.createNft(nftToCreate);

  // ** create proccess tracking */
  await processTrackingService.createTracking({
    ...nftToCreate,
    transactionHash,
    userAddress: ownerAddress,
    networkId,
    action: PROCESS_TRAKING_ACTION.CANCEL_AUCTION,
    processStatus: PROCESS_TRAKING_STATUS.AFTER,
  });

  //* fire event
  eventPool.fireEvent({
    eventName,
    ...nft.toObject(),
  });
};
