import nftService from '../../components/nfts/v1/nftService_v1';
import processTrackingService from '../../components/processTracking/v1/processTrackingService_v1';
import { MARKET_CONTRACT_EVENTS, MARKET_TYPE, PROCESS_TRAKING_ACTION, PROCESS_TRAKING_STATUS, STATUS } from '../enums';
import { getSimpleMarketItem } from '../utils';
const eventPool = require('../../components/events/v1/eventService_v1').default;

interface IEvent {
  listingId: string;
  buyer: string;
  quantity: number;
  transactionHash: string;
}
interface INftBuySimpleEvent {
  nftMarketSimpleContract: any;
  event: IEvent;
  eventName: MARKET_CONTRACT_EVENTS;
  web3: any;
  networkId: number;
}

export const buySimpleEvent = async (data: INftBuySimpleEvent) => {
  //* data
  const { nftMarketSimpleContract, event, eventName, web3, networkId } = data;
  console.log('🚀 ~ file: buySimpleEvent.ts ~ line 35 ~ buySimpleEvent ~ eventName', eventName);

  const { listingId, quantity, buyer, transactionHash } = event;
  console.log('🚀 ~ file: buySimpleEvent.ts ~ line 27 ~ buySimpleEvent ~ buyer', buyer);

  const marketitem = await getSimpleMarketItem({ nftMarketSimpleContract, listingId });
  const { nftContract, nftTokenId, price, ownerAddress, originalQuantity, remainingQuantity } = marketitem;

  const nftdetail = await nftService.getNftDetailesNoPopulate({
    tokenId: nftTokenId,
    nftAddress: nftContract,
    ownerAddress,
  });
  console.log('🚀 ~ file: buySimpleEvent.ts ~ line 45 ~ buySimpleEvent ~ nftdetail', nftdetail);

  const {
    name,
    description,
    imageUrl,
    attributes,
    multiple,
    collectionId,
    category,
    creatorAddress,
    nftAddress,
    royalty,
    tokenId,
  } = nftdetail;
  const pastAddress = ownerAddress;

  //* find on mongo id nft exist, to make sure the it saved only once on the db
  const existedItem = await nftService.getNftByTransactionHash({ transactionHash });
  if (existedItem) {
    console.log('🚀 ~ file: buySimpleEvent.ts ~ line 67 ~ buySimpleEvent ~ existedItem!!!!!');
    return;
  }

  const priceInEth = web3.utils.fromWei(price.toString(), 'ether');
  //** mongo item */
  const nftToCreate: any = {
    tokenId,
    price: priceInEth,
    transactionHash,
    name,
    description,
    imageUrl,
    attributes,
    creatorAddress,
    nftAddress,
    collectionId,
    royalty,
    marketType: MARKET_TYPE.SIMPLE,
    isListedOnce: true,
    multiple,
    networkId,
    category,
  };

  // * create mongo seller row
  const newone = await nftService.createNft({
    ...nftToCreate,
    price: priceInEth,
    ownerAddress: pastAddress,
    listingId,
    status: Number(remainingQuantity) > 0 ? STATUS.ON_SELL : STATUS.NOT_LISTED,
    leftAmount: 0,
    listedAmount: Number(remainingQuantity),
    totalAmount: Number(originalQuantity),
  });
  console.log('🚀 ~ file: buySimpleEvent.ts ~ line 101 ~ buySimpleEvent ~ newone', newone);

  let _listedAmount = 0;
  let _leftAmount = 0;
  let _totalAmount = 0;
  const buyerFields = async () => {
    const fields: any = {};
    if (multiple) {
      const nftGroups = await nftService.nftMultipleDetailes({
        tokenId,
        nftAddress: nftContract.toLowerCase(),
      });
      const buyerCurrentCollectible = nftGroups.find((group) => group.ownerAddress === buyer.toLowerCase());

      if (buyerCurrentCollectible) {
        _listedAmount = Number(buyerCurrentCollectible.listedAmount);
        _leftAmount = Number(buyerCurrentCollectible.leftAmount);
        _totalAmount = Number(buyerCurrentCollectible.totalAmount);
      }
      fields.status = buyerCurrentCollectible ? buyerCurrentCollectible.status : STATUS.NOT_LISTED;
      fields.price = buyerCurrentCollectible ? buyerCurrentCollectible.price : null;
      fields.listingId = buyerCurrentCollectible ? buyerCurrentCollectible.listingId : null;
    } else {
      fields.status = STATUS.NOT_LISTED;
      fields.price = null;
      fields.listingId = null;
    }

    return fields;
  };

  const _buyerFields = await buyerFields();
  // * create mongo buyer row
  const buyerNftResultAfterBuying: any = await nftService.createNft({
    ...nftToCreate,
    ownerAddress: buyer,
    totalAmount: Number(quantity) + Number(_totalAmount),
    leftAmount: Number(quantity) + Number(_leftAmount),
    listedAmount: _listedAmount,
    transactionHash,
    ..._buyerFields,
  });
  console.log(
    '🚀 ~ file: buySimpleEvent.ts ~ line 130 ~ buySimpleEvent ~ buyerNftResultAfterBuying',
    buyerNftResultAfterBuying,
  );

  // ** create proccess tracking */
  await processTrackingService.createTracking({
    ...nftToCreate,
    transactionHash,
    userAddress: buyer,
    networkId,
    action: multiple ? PROCESS_TRAKING_ACTION.BUY_SIMPLE_MULTIPLE : PROCESS_TRAKING_ACTION.BUY_SIMPLE_SINGLE,
    processStatus: PROCESS_TRAKING_STATUS.AFTER,
  });

  //* fire event
  eventPool.fireEvent({
    eventName,
    ...buyerNftResultAfterBuying.toObject(),
  });
};
