import nftService from '../../components/nfts/v1/nftService_v1';
import processTrackingService from '../../components/processTracking/v1/processTrackingService_v1';
import { MARKET_CONTRACT_EVENTS, MARKET_TYPE, PROCESS_TRAKING_ACTION, PROCESS_TRAKING_STATUS, STATUS } from '../enums';
const eventPool = require('../../components/events/v1/eventService_v1').default;

interface IEvent {
  listingId: string;
  _nftContractAddress: string;
  tokenId: string;
  tokenURI: string;
  startPrice: number;
  deadline: number;
  creatorAddress: string;
  sellerAddress: string;
  royalty: number;
  frontData: any;
  transactionHash: string;
}

interface INftAuctionMarketItemCreatedEvent {
  event: IEvent;
  eventName: MARKET_CONTRACT_EVENTS;
  web3: any;
  networkId: number;
}

export const auctionItemCreatedEvent = async (data: INftAuctionMarketItemCreatedEvent) => {
  //* data
  const { event, eventName, web3, networkId } = data;
  const { listingId, transactionHash } = event;
  //* find on mongo id nft exist, to make sure the it saved only once on the db
  const existedItem = await nftService.getNftByTransactionHash({ transactionHash });

  if (existedItem) {
    console.log('existedItem!!!');
    return;
  }

  //** mongo item */
  const nftToCreate: any = {
    listingId,
    transactionHash,
    networkId,
    flag: false,
  };

  // * create mongo row
  await nftService.createNft(nftToCreate);
};
