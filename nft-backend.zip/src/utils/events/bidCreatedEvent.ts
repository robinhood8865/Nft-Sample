import bidService from '../../components/bids/v1/bidsService_v1';
import processTrackingService from '../../components/processTracking/v1/processTrackingService_v1';
import { MARKET_CONTRACT_EVENTS, PROCESS_TRAKING_ACTION, PROCESS_TRAKING_STATUS } from '../enums';
import { nft721ContractAddress } from '../web31';
const eventPool = require('../../components/events/v1/eventService_v1').default;

interface IEvent {
  listingId: string;
  bidIndex: string;
  bidAmount: number;
  transactionHash: string;
}
interface IBidCreatedEvent {
  nftMarketAuctionContract: any;
  event: IEvent;
  eventName: MARKET_CONTRACT_EVENTS;
  web3: any;
  networkId: number;
}

export const bidCreatedEvent = async (data: IBidCreatedEvent) => {
  //* data
  const { nftMarketAuctionContract, event, eventName, web3, networkId } = data;
  console.log('🚀 ~ file: bidCreatedEvent.ts ~ line 26 ~ bidCreatedEvent ~ eventName', eventName);

  //* event
  const { listingId, bidIndex, bidAmount, transactionHash } = event;

  const AuctionBid = await nftMarketAuctionContract.methods.auctionBids(listingId, bidIndex).call();
  console.log('🚀 ~ file: bidCreatedEvent.ts ~ line 30 ~ bidCreatedEvent ~ AuctionBid', AuctionBid);
  const buyerAddress = AuctionBid.bidder;
  const priceInEth = web3.utils.fromWei(bidAmount.toString(), 'ether');

  //* find on mongo id bid exist, to make sure the it saved only once on the db
  const existedBid = await bidService.getBidByTransactionHash({ transactionHash });

  if (existedBid) {
    console.log('existedBid!!!');
    return;
  }

  //** create bid on mongo*/
  const res: any = await bidService.createBid({
    price: priceInEth,
    buyerAddress,
    listingId,
    tokenId: bidIndex,
    networkId,
    transactionHash,
    nftAddress: nft721ContractAddress,
  });

  //** create proccess tracking */
  await processTrackingService.createTracking({
    transactionHash,
    listingId,
    tokenId: bidIndex,
    nftAddress: nft721ContractAddress,
    price: priceInEth,
    userAddress: buyerAddress,
    networkId,
    action: PROCESS_TRAKING_ACTION.BID,
    processStatus: PROCESS_TRAKING_STATUS.AFTER,
  });

  //* fire event
  eventPool.fireEvent({
    eventName,
    ...res.toObject(),
  });
};
