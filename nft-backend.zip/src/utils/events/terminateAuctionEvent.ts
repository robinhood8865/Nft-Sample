import moment from 'moment';
import nftService from '../../components/nfts/v1/nftService_v1';
import processTrackingService from '../../components/processTracking/v1/processTrackingService_v1';
import {
  IAuctionMarketItem,
  MARKET_CONTRACT_EVENTS,
  MARKET_TYPE,
  PROCESS_TRAKING_ACTION,
  PROCESS_TRAKING_STATUS,
  STATUS,
} from '../enums';
const eventPool = require('../../components/events/v1/eventService_v1').default;

interface IEvent {
  listingId: string;
  _nftContractAddress: string;
  tokenId: string;
  price: number;
  creatorAddress: string;
  sellerAddress: string;
  buyerAddress: string;
  bidderAddress: string;
  terminatorAddress: string;
  royalty: number;
  frontData: any;
  tokenURI: string;
  transactionHash: string;
}

interface INftTerminateAuctionEvent {
  nftMarketAuctionContract: any;
  event: IEvent;
  eventName: MARKET_CONTRACT_EVENTS;
  web3: any;
  networkId: number;
}

export const terminateAuctionEvent = async (data: INftTerminateAuctionEvent) => {
  //* data
  const { nftMarketAuctionContract, event, eventName, web3, networkId } = data;
  console.log('🚀 ~ file: terminateAuctionEvent.ts ~ line 43 ~ terminateAuctionEvent ~ eventName', eventName);
  const {
    listingId,
    tokenId,
    tokenURI,
    creatorAddress,
    sellerAddress,
    bidderAddress,
    terminatorAddress,
    royalty,
    frontData,
    transactionHash,
  } = event;

  // const frontData = JSON.parse(frontDataString);
  console.log('🚀 ~ file: terminateAuctionEvent.ts ~ line 60 ~ terminateAuctionEvent ~ frontData', frontData);

  const { name, description, imageUrl, attributes, multiple, collectionId, category } = frontData;

  //* find on mongo id nft exist, to make sure the it saved only once on the db
  const existedItem = await nftService.getNftByTransactionHash({ transactionHash });

  if (existedItem) {
    console.log('existedItem!!!');
    return;
  }
  const _attributes = attributes.map((item: any) => {
    return {
      display_type: item.display_type,
      trait_type: item.trait_type,
      value: item.value,
    };
  });
  const auctionMarketItem: IAuctionMarketItem = await nftMarketAuctionContract.methods
    .auctionListingIdToMarketItem(Number(listingId))
    .call();
  const ZERO_ADDRESS = web3.utils.padLeft('0x0', 40);

  // console.log('balanceInEth===>', balanceInEth);

  //** create nft */
  const nftToCreate: any = {
    listingId,
    tokenId,
    tokenURI,
    transactionHash,
    name,
    description,
    imageUrl,
    attributes: _attributes,
    creatorAddress: creatorAddress,
    // nftAddress: nftContractAddress,
    collectionId,
    royalty,
    marketType: MARKET_TYPE.AUCTION,
    status: STATUS.NOT_LISTED,
    isListedOnce: true,
    multiple,
    networkId,
    category,
  };
  console.log(
    '🚀 ~ file: terminateAuctionEvent.ts ~ line 106 ~ terminateAuctionEvent ~ auctionMarketItem.currentBidderAddress',
    auctionMarketItem.currentBidderAddress,
  );
  console.log('🚀 ~ file: terminateAuctionEvent.ts ~ line 107 ~ terminateAuctionEvent ~ ZERO_ADDRESS', ZERO_ADDRESS);

  // * create mongo row
  let nft: any;
  if (auctionMarketItem.currentBidderAddress === ZERO_ADDRESS) {
    // seller
    nft = await nftService.createNft({
      ...nftToCreate,
      ownerAddress: sellerAddress,
    });

    //* create tracking after terminate auction
    await processTrackingService.createTracking({
      ...nftToCreate,
      userAddress: terminatorAddress,
      ownerAddress: sellerAddress,
      action: PROCESS_TRAKING_ACTION.TERMINATE_AUCTION_NOT_SOLD,
      processStatus: PROCESS_TRAKING_STATUS.AFTER,
    });
  } else {
    const currentBid = web3.utils.fromWei(auctionMarketItem.currentBid, 'ether');

    // seller
    await nftService.createNft({
      ...nftToCreate,
      price: currentBid, // price here to know for how mush got sold
      ownerAddress: sellerAddress,
      status: STATUS.NOT_LISTED, // very importnat to update the seller status
    });

    // buyer - highest bidder
    nft = await nftService.createNft({
      ...nftToCreate,
      ownerAddress: auctionMarketItem.currentBidderAddress,
      status: STATUS.NOT_LISTED,
    });

    //* create tracking after terminate auction
    await processTrackingService.createTracking({
      ...nftToCreate,
      userAddress: terminatorAddress,
      ownerAddress: auctionMarketItem.currentBidderAddress,
      price: currentBid, // price here to know for how mush got sold
      action: PROCESS_TRAKING_ACTION.TERMINATE_AUCTION_SOLD,
      processStatus: PROCESS_TRAKING_STATUS.AFTER,
    });
  }

  //* fire event
  eventPool.fireEvent({
    eventName,
    terminatorAddress,
    ...nft.toObject(),
  });
};
