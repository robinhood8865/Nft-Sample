import express from 'express';
import authController from './authController_v1';
// import { validate } from '../../../middleware/validators';
// import { getUserProfileValidator } from './usersValidators_v1';


const router = express.Router();


//**
// create user
router.post('/', authController.auth);

router.post('/refresh', authController.refresh);

export default router;
