import { Response, NextFunction } from 'express';
import config from 'config';
import { recoverPersonalSignature } from 'eth-sig-util';
import { bufferToHex } from 'ethereumjs-util';
import jwt from 'jsonwebtoken';
import { GeneralError } from '../../../utils/errors';
import logger from '../../../utils/logger';

import userService from '../../users/v1/usersService_v1';
import { IUser } from '../../../types/users.types';
import { ERRORS, TOKEN_LIFE } from '../../../utils/enums';

const secret = process.env.secret || (config.get('secret') as string);
const refreshSecret = process.env.refreshSecret || (config.get('refreshSecret') as string);
const auth = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  const { publicAddress, signature } = req.body;
  try {
    ////////////////////////////////////////////////////
    // Step 1: Get the user with the given publicAddress
    ////////////////////////////////////////////////////
    const user = (await userService.getUserProfile({ publicAddress })) as IUser;
    if (!user) {
      throw new GeneralError(`Auth - User with address ${publicAddress} doesn't exists`);
    }

    const msg = `I am signing my one-time nonce: ${user.nonce}`;

    // We now are in possession of msg, publicAddress and signature. We
    // will use a helper from eth-sig-util to extract the address from the signature
    const msgBufferHex = bufferToHex(Buffer.from(msg, 'utf8'));

    // getting the public address from the signature and the message
    const address = recoverPersonalSignature({
      data: msgBufferHex,
      sig: signature,
    });

    // The signature verification is successful if the address found with
    // ecrecover matches the initial publicAddress
    if (address.toLowerCase() === publicAddress.toLowerCase()) {
      ////////////////////////////////////////////////////
      // Step 3: Generate a new nonce for the user
      ////////////////////////////////////////////////////
      const nonce = Math.floor(Math.random() * 10000);
      const updatedUser = await userService.updateNonce({ publicAddress: publicAddress, nonce });
      console.log('🚀 ~ file: authController_v1.ts ~ line 47 ~ auth ~ updatedUser', updatedUser);

      ////////////////////////////////////////////////////
      // Step 4: Create JWT
      ////////////////////////////////////////////////////
      const signData = {
        payload: {
          _id: user._id,
          username: user.username,
          publicAddress,
        },
      };

      const accessToken = jwt.sign(signData, secret, { expiresIn: TOKEN_LIFE.ACCESS_TOKEN });
      const refreshToken = jwt.sign(signData, refreshSecret, { expiresIn: TOKEN_LIFE.REFRESH_TOKEN });

      res.send({ accessToken, refreshToken });
    } else {
      res.send().status(401).send({ error: 'Signature verification failed' });
    }
  } catch (error) {
    logger.error('error in auth', error);
    next(error);
  }
};

const refresh = async (req: any, res: Response): Promise<void> => {
  const { refreshToken } = req.body;
  // if refresh token exists
  if (refreshToken) {
    try {
      const { payload } = jwt.verify(refreshToken, refreshSecret) as any;
      console.log('🚀 ~ file: authController_v1.ts ~ line 78 ~ refresh ~ payload', payload);
      const token = jwt.sign({ payload }, secret, { expiresIn: TOKEN_LIFE.ACCESS_TOKEN });
      res.status(200).send(token);
    } catch (err) {
      res.status(401).send(ERRORS.TOKEN_INVALID);
    }
  } else {
    res.status(404).send(ERRORS.INVALID_REQUEST);
  }
};

const userController = {
  auth,
  refresh,
};

export default userController;
