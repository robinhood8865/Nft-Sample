import express from 'express';
import collectionController_v1 from './collectionsController_v1';
import { validate } from '../../../middleware/validators';
import { createCollectionValidator, getCollectionValidator, getMyCollectionsValidator, getTopCollectionsValidator } from './collectionsValidators_v1';

const router = express.Router();

// create collection
router.post('/',
  createCollectionValidator,
  validate,
  collectionController_v1.createCollection);

// get collections
router.get('/',
  collectionController_v1.getCollections,
);

// get collection
router.get('/getCollection',
  getCollectionValidator,
  validate,
  collectionController_v1.getCollection);

// get my collections
router.get('/getMyCollections',
  getMyCollectionsValidator, getTopCollectionsValidator,
  validate,
  collectionController_v1.getMyCollections);

// get top collections
router.get('/getTopCollections',
  getTopCollectionsValidator,
  validate,
  collectionController_v1.getTopCollections);

// //**
// // update collections
// router.put('/',
//   // validations
//   // getStaticContentsByHospitalCodeValidator,
//   validate,
//   collectionController_v1.updateCollection);

export default router;
