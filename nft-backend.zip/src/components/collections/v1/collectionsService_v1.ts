import { GeneralError } from '../../../utils/errors';
import { ICollection } from '../../../types/collections.types';
import { NftCollection } from '../collectionDal';

const createCollection = async (data: ICollection): Promise<ICollection> => {
  const collection = new NftCollection(data);
  const _collection = await collection.save();
  return _collection;
};

const getCollections = async (): Promise<ICollection[]> => {
  const collections: any = await NftCollection.find();
  return collections;
};

const getCollection = async (data: { collectionId: string }): Promise<ICollection[]> => {
  const { collectionId } = data;
  const collection: any = await NftCollection.findOne({ id: collectionId }).populate('user');
  if (!collection) {
    throw new GeneralError(`not collection with id ${collectionId}`);
  }
  return collection;
};

const getMyCollections = async (data: { userAddress: string }): Promise<ICollection[]> => {
  const { userAddress } = data;

  const collections: any = await NftCollection.find({
    userAddress,
  }).populate('user');
  return collections;
};

// const updateCollection = async (data: any) => {
//   const { mongoId, status, ownerAddress, tokenId } = data;
// };

const searchCollections = async (
  match: string,
  pageLimit?: number,
  currentPage?: number,
): Promise<any[]> => {
  const _currentPage = currentPage || 0;

  // It should as least have limit
  if (pageLimit) {
    return NftCollection.aggregate([
      {
        $match: { name: { $regex : `.*${match}.*`, $options: 'i' } },
      }, {
        $lookup: {
          from: "users",
          localField: "userAddress",
          foreignField: "publicAddress",
          as: "user",
        },
      }, {
        $facet: {
          data: [
            { $skip: _currentPage as number * pageLimit },
            { $limit: pageLimit },
          ],
          pagination: [{ $count: 'totalCount' }],
        },
      }, {
        $unwind: "$pagination",
      },
    ]);
  } else {
    return [];
  }
};

const collectionService = {
  createCollection,
  getCollections,
  getCollection,
  getMyCollections,
  // updateCollection,
  searchCollections,
};

export default collectionService;
