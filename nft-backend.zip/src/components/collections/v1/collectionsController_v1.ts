import { Response, NextFunction } from 'express';
import logger from '../../../utils/logger';
import collectionService from './collectionsService_v1';
import processTrackingService from '../../processTracking/v1/processTrackingService_v1';
import { ONE_DAY, PROCESS_TRAKING_ACTION, PROCESS_TRAKING_STATUS } from '../../../utils/enums';
const createCollection = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  // const { creatorAddress, ownerAddress, tokenId, title, description, imageUrl, marketType, price } = req.body;

  try {
    const newCollection: any = await collectionService.createCollection(req.body);
    res.send(newCollection);
  } catch (error) {
    logger.error('error in createCollection', error);
    next(error);
  }
};

const getCollections = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  try {
    const collections: any = await collectionService.getCollections();
    res.send(collections);
  } catch (error) {
    logger.error('error in getCollections', error);
    next(error);
  }
};

const getCollection = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  const { collectionId } = req.query;

  try {
    const newCollection: any = await collectionService.getCollection({ collectionId });
    res.send(newCollection);
  } catch (error) {
    logger.error('error in getCollection', error);
    next(error);
  }
};

const getMyCollections = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  const { userAddress } = req.query;
  try {
    const newCollection: any = await collectionService.getMyCollections({ userAddress });
    res.send(newCollection);
  } catch (error) {
    logger.error('error in getMyCollections', error);
    next(error);
  }
};

// const updateCollection = async (req: any, res: Response, next: NextFunction): Promise<void> => {
//   // const { creatorAddress, ownerAddress, tokenId, title, description, imageUrl, marketType, price } = req.body;

//   try {
//     const newCollection: any = await collectionService.updateCollection(req.body);
//     res.send(newCollection);
//   } catch (error) {
//     logger.error('error in updateCollection', error);
//     next(error);
//   }
// };



const getTopCollections = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  const { limit, day } = req.query;
  try {
    const timestamp = new Date().getTime() - ONE_DAY * day;
    const date = new Date(timestamp);
    const topCollections = await processTrackingService.getTopCollections({
      processStatus: PROCESS_TRAKING_STATUS.AFTER,
      actions: [
        PROCESS_TRAKING_ACTION.BUY_SIMPLE_SINGLE,
        PROCESS_TRAKING_ACTION.BUY_SIMPLE_MULTIPLE,
        PROCESS_TRAKING_ACTION.TERMINATE_AUCTION_SOLD,
      ],
      limit,
      date,
    });

    res.send(topCollections);
  } catch (error) {
    logger.error('error in getTopCollections', error);
    next(error);
  }
};


const collectionController = {
  createCollection,
  getCollections,
  getCollection,
  getMyCollections,
  // updateCollection,
  getTopCollections,
};

export default collectionController;
