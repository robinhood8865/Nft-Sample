import { body, query } from 'express-validator';
import { DEFAULT_TIMEFRAME } from '../../../utils/enums';

export const createCollectionValidator = [
  body('name').isString(),
  body('userAddress').isString(),
  body('description').isString(),
  body('imageUrl').isString(),
];

export const getCollectionValidator = [
  query('collectionId').isString(),
];

export const getMyCollectionsValidator = [
  query('userAddress').isString(),
];

export const getTopCollectionsValidator = [
  query('limit', 'Limit is not valid').default(10).isInt().toInt(),
  query('day', 'Day is not valid').default(DEFAULT_TIMEFRAME.THIRTY).isInt().toInt(),
];