import mongoose, { Document } from 'mongoose';
import { ICollection } from '../../types/collections.types';

const NftCollectionSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    id: {
      type: String,
      required: true,
      unique: true,
    },
    description: {
      type: String,
    },
    imageUrl: {
      type: String,
    },
    userAddress: {
      type: String,
      required: true,
      lowercase: true,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true }, // So `res.json()` and other `JSON.stringify()` functions include virtuals
    toObject: { virtuals: true },
  },
);

NftCollectionSchema.virtual('user', {
  ref: 'User',
  localField: 'userAddress',
  foreignField: 'publicAddress',
});

export const NftCollection = mongoose.model<ICollection & Document>('NftCollection', NftCollectionSchema);
