import mongoose, { Document } from 'mongoose';
import { IProcessTracking } from '../../types/processTracking.types';
import { MARKET_TYPE, PROCESS_TRAKING_STATUS, PROCESS_TRAKING_ACTION } from '../../utils/enums';

const ProcessTrackingSchema = new mongoose.Schema(
  {
    action: {
      type: String,
      enum: [
        PROCESS_TRAKING_ACTION.CREATE_SIMPLE_SINGLE,
        PROCESS_TRAKING_ACTION.CREATE_SIMPLE_MULTIPLE,
        PROCESS_TRAKING_ACTION.CREATE_AUCTION,
        PROCESS_TRAKING_ACTION.LIST_SIMPLE_SINGLE,
        PROCESS_TRAKING_ACTION.LIST_SIMPLE_MULTIPLE,
        PROCESS_TRAKING_ACTION.LIST_AUCTION,
        PROCESS_TRAKING_ACTION.CANCEL_SIMPLE_SINGLE,
        PROCESS_TRAKING_ACTION.CANCEL_SIMPLE_MULTIPLE,
        PROCESS_TRAKING_ACTION.CANCEL_AUCTION,
        PROCESS_TRAKING_ACTION.BUY_SIMPLE_SINGLE,
        PROCESS_TRAKING_ACTION.BUY_SIMPLE_MULTIPLE,
        PROCESS_TRAKING_ACTION.BID,
        PROCESS_TRAKING_ACTION.TERMINATE_AUCTION_NOT_SOLD,
        PROCESS_TRAKING_ACTION.TERMINATE_AUCTION_SOLD,
      ],
      required: true,
    },
    processStatus: {
      type: String,
      enum: [PROCESS_TRAKING_STATUS.BEFORE, PROCESS_TRAKING_STATUS.AFTER],
      required: true,
    },
    userAddress: {
      type: String,
      required: true,
      lowercase: true,
    },
    tokenId: {
      type: String,
    },
    creatorAddress: {
      type: String,
      lowercase: true,
    },
    ownerAddress: {
      type: String,
      lowercase: true,
    },
    category: {
      type: String,
    },
    royalty: {
      type: Number,
    },
    transactionHash: {
      type: String,
    },
    marketType: {
      type: String,
      enum: [MARKET_TYPE.SIMPLE, MARKET_TYPE.AUCTION],
    },
    imageUrl: {
      type: String,
    },
    listingId: {
      type: String,
    },
    deadline: {
      type: String,
    },
    collectionId: {
      type: String,
    },
    nftAddress: {
      type: String,
      lowercase: true,
    },
    totalAmount: {
      type: Number,
    },
    networkId: {
      type: Number,
    },
    leftAmount: {
      type: Number,
    },
    listedAmount: {
      type: Number,
    },
    multiple: {
      type: Boolean,
    },
    name: {
      type: String,
    },
    description: {
      type: String,
    },
    price: {
      type: Number,
    },
    minimumBid: {
      type: String,
    },
    expirationDate: {
      type: Date,
    },
    listedAt: {
      type: Date,
    },

  },
  {
    timestamps: true,
    toJSON: { virtuals: true }, // So `res.json()` and other `JSON.stringify()` functions include virtuals
    toObject: { virtuals: true },
  },
);

ProcessTrackingSchema.virtual('user', {
  ref: 'User',
  localField: 'userAddress',
  foreignField: 'publicAddress',
});

ProcessTrackingSchema.virtual('creator', {
  ref: 'User',
  localField: 'creatorAddress',
  foreignField: 'publicAddress',
});
ProcessTrackingSchema.virtual('owner', {
  ref: 'User',
  localField: 'ownerAddress',
  foreignField: 'publicAddress',
});

ProcessTrackingSchema.virtual('nftCollection', {
  ref: 'NftCollection',
  localField: 'collectionId',
  foreignField: 'id',
});

export const ProcessTracking = mongoose.model<IProcessTracking & Document>('processTracking', ProcessTrackingSchema);
