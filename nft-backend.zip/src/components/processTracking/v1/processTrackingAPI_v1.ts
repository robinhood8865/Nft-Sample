import express from 'express';
import processTrackingController from './processTrackingController_v1';
import auth from '../../../middleware/auth';
import { validate } from '../../../middleware/validators';
import { createTrackingValidator } from './processTrackingValidators_v1';

const router = express.Router();

router.post('/', createTrackingValidator, validate, auth, processTrackingController.createTracking);

export default router;
