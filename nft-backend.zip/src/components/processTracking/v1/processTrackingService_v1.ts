import { IProcessTracking, TrackingServiceFuncProps } from '../../../types/processTracking.types';
import { ProcessTracking } from './../processTrackingDal';
import { PROCESS_TRAKING_STATUS, PROCESS_TRAKING_ACTION } from '../../../utils/enums';

const createTracking = async (data: IProcessTracking): Promise<IProcessTracking> => {
  const processTracking = new ProcessTracking(data);
  const _processTracking = await processTracking.save();
  return _processTracking;
};

const getTrackings = async (data: {
  processStatus?: PROCESS_TRAKING_STATUS;
  actions?: PROCESS_TRAKING_ACTION[];
}): Promise<IProcessTracking[]> => {
  const { processStatus, actions } = data;

  const processTrackings: IProcessTracking[] = await ProcessTracking.find({ processStatus, action: { $in: actions } });
  console.log(
    'processTrackings actions==>',
    processTrackings.map((p) => p.action),
  );

  return processTrackings;
};

const getTopCollections = async (data: TrackingServiceFuncProps): Promise<IProcessTracking[]> => {
  const { processStatus, actions, limit, date } = data;

  const tracks: any = ProcessTracking.aggregate([
    {
      $match: {
        processStatus,
        action: { $in: actions },
        collectionId: { $nin: [null, ''] },
        createdAt: { $gte: date },
      },
    },
    { $sort: { createdAt: 1 } },
    {
      $group: {
        _id: { collectionId: '$collectionId' },
        mongoId: { $last: '$_id' },
        createdAt: { $first: '$createdAt' },
        collectionId: { $first: '$collectionId' },
        tokenId: { $last: '$tokenId' },
        listingId: { $last: '$listingId' },
        expirationDate: { $last: '$expirationDate' },
        creatorAddress: { $last: '$creatorAddress' },
        ownerAddress: { $last: '$ownerAddress' },
        nftAddress: { $last: '$nftAddress' },
        multiple: { $last: '$multiple' },
        networkId: { $last: '$networkId' },
        totalAmount: { $last: '$totalAmount' },
        leftAmount: { $last: '$leftAmount' },
        listedAmount: { $last: '$listedAmount' },
        category: { $last: '$category' },
        royalty: { $last: '$royalty' },
        marketType: { $last: '$marketType' },
        status: { $last: '$status' },
        imageUrl: { $last: '$imageUrl' },
        deadline: { $last: '$deadline' },
        name: { $last: '$name' },
        description: { $last: '$description' },
        price: { $sum: '$price' }, // sum!!
        listedAt: { $last: '$listedAt' },
        isListedOnce: { $last: '$isListedOnce' },
      },
    },
    {
      $lookup: {
        from: 'users',
        localField: 'creatorAddress',
        foreignField: 'publicAddress',
        as: 'creator',
      },
    },
    {
      $lookup: {
        from: 'nftcollections',
        localField: 'collectionId',
        foreignField: 'id',
        as: 'nftCollection',
      },
    },
    { $sort: { price: -1 } }, // from high to low
    // { $limit: 15 } //    soon we'll add this
  ]);
  console.log('🚀 ~ file: processTrackingService_v1.ts ~ line 28 ~ getTopCollections ~ limit', limit);

  if (limit) {
    tracks.limit(limit);
  }

  return tracks;
};

const getNftHistory = async (data: {
  processStatus?: PROCESS_TRAKING_STATUS;
  actions?: PROCESS_TRAKING_ACTION[];
  tokenId: string;
  nftAddress: string;
}): Promise<IProcessTracking[]> => {
  const { processStatus, actions, tokenId, nftAddress } = data;
  const tracks: any = ProcessTracking.find({
    tokenId,
    nftAddress,
    processStatus,
    action: { $in: actions },
  })
    .sort({ createdAt: 1 }) // from old to new
    .populate('user');

  return tracks;
};

const getTopSellers = async (data: TrackingServiceFuncProps): Promise<IProcessTracking[]> => {
  const { processStatus, actions, limit, date } = data;

  const tracks: any = ProcessTracking.aggregate([
    {
      $match: {
        processStatus,
        action: { $in: actions },
        ownerAddress: { $nin: [null, ''] },
        createdAt: { $gte: date },
      },
    },
    {
      $sort: { createdAt: 1 },
    },
    {
      $group: {
        _id: { ownerAddress: '$ownerAddress' },
        ownerAddress: { $last: '$ownerAddress' },
        price: { $sum: '$price' }, // sum!!
      },
    },
    {
      $lookup: {
        from: 'users',
        localField: 'ownerAddress',
        foreignField: 'publicAddress',
        as: 'userInfo',
      },
    },
    {
      $sort: { price: -1 },
    },
  ]);
  console.log('🚀 ~ file: processTrackingService_v1.ts ~ line 118 ~ getTopSellers ~ limit', limit);

  if (limit) {
    tracks.limit(limit);
  }

  return tracks;
};

const getTopBuyers = async (data: TrackingServiceFuncProps): Promise<IProcessTracking[]> => {
  const { processStatus, actions, limit, date } = data;

  const tracks: any = ProcessTracking.aggregate([
    {
      $match: {
        processStatus,
        action: { $in: actions },
        userAddress: { $nin: [null, ''] },
        createdAt: { $gte: date },
      },
    },
    {
      $sort: { createdAt: 1 },
    },
    {
      $group: {
        _id: { userAddress: '$userAddress' },
        userAddress: { $last: '$userAddress' },
        price: { $sum: '$price' }, // sum!!
      },
    },
    {
      $lookup: {
        from: 'users',
        localField: 'userAddress',
        foreignField: 'publicAddress',
        as: 'userInfo',
      },
    },
    {
      $sort: { price: -1 },
    },
  ]);

  if (limit) {
    tracks.limit(limit);
  }

  return tracks;
};

const processTrackingService = {
  createTracking,
  getTrackings,
  getNftHistory,
  getTopCollections,
  getTopSellers,
  getTopBuyers,
};

export default processTrackingService;
