import { body } from 'express-validator';
import { MARKET_TYPE, PROCESS_TRAKING_ACTION, PROCESS_TRAKING_STATUS } from '../../../utils/enums';

export const createTrackingValidator = [
  body('action', 'Action is not valid').isIn([
    PROCESS_TRAKING_ACTION.CREATE_SIMPLE_SINGLE,
    PROCESS_TRAKING_ACTION.CREATE_SIMPLE_MULTIPLE,
    PROCESS_TRAKING_ACTION.CREATE_AUCTION,
    PROCESS_TRAKING_ACTION.LIST_SIMPLE_SINGLE,
    PROCESS_TRAKING_ACTION.LIST_SIMPLE_MULTIPLE,
    PROCESS_TRAKING_ACTION.LIST_AUCTION,
    PROCESS_TRAKING_ACTION.CANCEL_SIMPLE_SINGLE,
    PROCESS_TRAKING_ACTION.CANCEL_SIMPLE_MULTIPLE,
    PROCESS_TRAKING_ACTION.CANCEL_AUCTION,
    PROCESS_TRAKING_ACTION.BUY_SIMPLE_SINGLE,
    PROCESS_TRAKING_ACTION.BUY_SIMPLE_MULTIPLE,
    PROCESS_TRAKING_ACTION.BID,
    PROCESS_TRAKING_ACTION.TERMINATE_AUCTION_NOT_SOLD,
    PROCESS_TRAKING_ACTION.TERMINATE_AUCTION_SOLD,
  ]),
  body('processStatus', 'Process status is not valid')
    .isIn([
      PROCESS_TRAKING_STATUS.BEFORE,
      PROCESS_TRAKING_STATUS.AFTER,
    ]),
  body('userAddress', 'User Address is not valid').isString(),
  body('tokenId', 'Token Id is not valid').isString().optional(),
  body('creatorAddress', 'Creator Address is not valid').isString().optional(),
  body('ownerAddress', 'Owner Address is not valid').isString().optional(),
  body('category', 'Category is not valid').isString().optional(),
  body('royalty', 'Royalty is not valid').isNumeric().optional().toFloat(),
  body('transactionHash', 'Transaction hash is not valid').isString().optional(),
  body('marketType', 'Market type is not valid')
    .isIn([MARKET_TYPE.SIMPLE, MARKET_TYPE.AUCTION])
    .optional(),
  body('imageUrl', 'Image url is not valid').isString().optional(),
  body('listingId', 'ListingId is not valid').isString().optional({ nullable: true }),
  body('deadline', 'Deadline is not valid').isString().optional(),
  body('collectionId', 'CollectionId is not valid').isString().optional(),
  body('nftAddress', 'NftAddress is not valid').isString().optional(),
  body('totalAmount', 'TotalAmount is not valid').isNumeric().optional().toFloat(),
  body('networkId', 'NetworkId is not valid').isInt().optional().toInt(),
  body('leftAmount', 'LeftAmount is not valid').isNumeric().optional().toFloat(),
  body('listedAmount', 'ListedAmount is not valid').isNumeric().optional().toFloat(),
  body('multiple', 'Multiple is not valid').isBoolean().optional(),
  body('name', 'Name is not valid').isString().optional(),
  body('description', 'Description is not valid').isString().optional(),
  body('price', 'Price is not valid').isNumeric().toFloat().optional(),
  body('minimumBid', 'MinimumBid is not valid').isString().optional(),
  body('expirationDate', 'ExpirationDate is not valid').isString().optional(),
  body('listedAt', 'ListedAt is not valid').isString().optional(),
];