import { Response, NextFunction } from 'express';

import processTrackingService from './processTrackingService_v1';
import logger from '../../../utils/logger';
import { GeneralError } from '../../../utils/errors';

const createTracking = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  console.log('🚀 ~ file: processTrackingController_v1.ts ~ line 8 ~ createTracking');
  if (!req.user) {
    throw new GeneralError('Error');
  }
  const { publicAddress } = req.user.payload;

  const dataToSave = { ...req.body, userAddress: publicAddress };
  console.log('🚀 ~ file: processTrackingController_v1.ts ~ line 14 ~ createTracking ~ dataToSave', dataToSave);
  try {
    const tracking: any = await processTrackingService.createTracking(dataToSave);
    res.send(tracking);
  } catch (error) {
    logger.error('error in createTracking', error);
    next(error);
  }
};

const trackingAPI = {
  createTracking,
};

export default trackingAPI;
