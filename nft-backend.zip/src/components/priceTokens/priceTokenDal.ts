import mongoose, { Document } from 'mongoose';
import { IPriceToken } from '../../types/priceTokens.types';

const PriceTokenSchema = new mongoose.Schema({
  name: {
    type: String,
  },
  address: {
    type: String,
    lowercase: true,
  },
});

export const PriceToken = mongoose.model<IPriceToken & Document>('PriceToken', PriceTokenSchema);
