import express from 'express';
import priceTokensController from './priceTokensController_v1';

import { validate } from '../../../middleware/validators';
// import {

// } from './priceTokensValidators_v1';

const router = express.Router();

//**
// get priceTokens
router.get('/', validate, priceTokensController.getpriceTokens);

export default router;
