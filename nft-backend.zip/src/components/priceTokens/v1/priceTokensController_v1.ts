import { Request, Response, NextFunction } from 'express';
import logger from '../../../utils/logger';
// import processTrackingService from '../../processTracking/v1/processTrackingService_v1';
import PriceTokensService from './priceTokensService_v1';

const getpriceTokens = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const pricetokens = await PriceTokensService.getPriceTokens();
    console.log('🚀 ~ file: priceTokensController_v1.ts ~ line 9 ~ getpriceTokens ~ pricetokens', pricetokens);

    res.send(pricetokens);
  } catch (error) {
    logger.error('error in getPriceTokens', error);
    next(error);
  }
};

const priceTokensController = {
  getpriceTokens,
};

export default priceTokensController;
