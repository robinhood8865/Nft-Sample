import { PriceToken } from '../priceTokenDal';
// import { IPriceToken } from '../../../types/priceTokens.types';

const getPriceTokens = async (): Promise<any> => {
  const priceTokens: any = await PriceToken.find({});
  return priceTokens;
};

const PriceTokensService = { getPriceTokens };

export default PriceTokensService;
