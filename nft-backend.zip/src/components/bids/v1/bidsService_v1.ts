import { IBid } from '../../../types/bids.types';
import { Bid } from '../bidDal';

const createBid = async (data: IBid): Promise<IBid> => {
  const bid = new Bid(data);
  const _bid = await bid.save();
  return _bid.populate('buyer').execPopulate();
};

const getBids = async (data: { listingId: string; nftAddress: string }): Promise<IBid[]> => {
  const { listingId, nftAddress } = data;
  console.log('🚀 ~ file: bidsService_v1.ts ~ line 12 ~ getBids ~ data', data);
  const bids: any = await Bid.find({
    listingId,
    nftAddress,
  })
    .populate('buyer')
    .sort({ createdAt: -1 });
  console.log('🚀 ~ file: bidsService_v1.ts ~ line 11 ~ getBids ~ bids', bids);
  return bids;
};

const getBidByTransactionHash = async (data: { transactionHash: string }): Promise<IBid> => {
  const { transactionHash } = data;
  const bid: any = await Bid.findOne({ transactionHash }).populate('buyer').sort({ createdAt: -1 });
  return bid;
};

// const cancelBid = async (): Promise<any> => {
//   // const { creatorAddress } = data;
//   const bids: any = await Bid.find({ status: STATUS.ON_SELL });
//   return bids;
// };

const bidService = {
  createBid,
  getBids,
  getBidByTransactionHash,
};

export default bidService;
