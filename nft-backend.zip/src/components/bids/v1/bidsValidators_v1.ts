import { check } from 'express-validator';

export const getBidValidator = [
  check('listingId').isString(),
];
