import { Response, NextFunction } from 'express';
import logger from '../../../utils/logger';
import bidService from './bidsService_v1';

const createBid = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  // const { creatorAddress, ownerAddress, tokenId, title, description, imageUrl, marketType, price } = req.body;

  try {
    const newBid: any = await bidService.createBid(req.body);
    res.send(newBid);
  } catch (error) {
    logger.error('error in createBid', error);
    next(error);
  }
};

const getBids = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  // const { creatorAddress, ownerAddress, tokenId, title, description, imageUrl, marketType, price } = req.body;

  try {
    const newBid: any = await bidService.getBids(req.query);
    res.send(newBid);
  } catch (error) {
    logger.error('error in updateBid', error);
    next(error);
  }
};

const bidController = {
  createBid,
  getBids,
};

export default bidController;
