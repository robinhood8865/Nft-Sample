import express from 'express';
import bidController_v1 from './bidsController_v1';
import { validate } from '../../../middleware/validators';
import { getBidValidator } from './bidsValidators_v1';

const router = express.Router();

//** delete soon
// create bid
router.post('/',
  // static content image
  // upload.single(IMAGES_NAMES.STATIC_CONTENT_IMAGE),
  // validations
  // createStaticContentValidator,
  // validate,
  // controller
  bidController_v1.createBid);

//**
// get bids
router.get('/',
  // validations
  // getBidValidator,
  validate,
  bidController_v1.getBids);
  
export default router;
