import mongoose, { Document } from 'mongoose';
import { IBid } from '../../types/bids.types';

const BidSchema = new mongoose.Schema(
  {
    buyerAddress: {
      type: String,
      lowercase: true,
    },
    transactionHash: {
      type: String,
    },
    price: {
      type: Number,
    },
    listingId: {
      type: String,
    },
    tokenId: {
      type: String,
    },
    nftAddress: {
      type: String,
      lowercase: true,
    },
    networkId: {
      type: String,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true }, // So `res.json()` and other `JSON.stringify()` functions include virtuals
    toObject: { virtuals: true },
  },
);


BidSchema.virtual('buyer', {
  ref: 'User',
  localField: 'buyerAddress',
  foreignField: 'publicAddress',
});


export const Bid = mongoose.model<IBid & Document>('Bid', BidSchema);
