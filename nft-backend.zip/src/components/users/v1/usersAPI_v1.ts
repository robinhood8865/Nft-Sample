import express from 'express';
import userController from './usersController_v1';
import { validate } from '../../../middleware/validators';
import upload from '../../../middleware/uploadImage';
import { IMAGES_NAMES } from '../../../utils/enums';
import { getUserNValidator, getUserByIdValidator, getTopSellersValidator, getTopBuysValidator, updateUserValidator, isRightUser } from './usersValidators_v1';
import auth from '../../../middleware/auth';

const router = express.Router();


//**
// create user
router.post('/',
  // static content image
  // upload.single(IMAGES_NAMES.STATIC_CONTENT_IMAGE),
  // validations
  // createStaticContentValidator,
  // validate,
  // controller
  userController.createUser);

//**
// get user nonce
router.get('/getUserN',
  // validations
  // auth,
  getUserNValidator,
  validate,
  userController.getUserN);

//**
// get user profile
router.get('/getUserById',
  // validations
  auth,
  getUserByIdValidator,
  validate,
  userController.getUserById);


//**
// update user
router.put('/',
  upload.single(IMAGES_NAMES.PROFILE_IMAGE),
  auth,
  isRightUser,
  updateUserValidator,
  validate,
  userController.updateUser);

//**
// get owner details
router.get('/getOwnerDetails',
  // validations
  // getStaticContentsByHospitalCodeValidator,
  validate,
  userController.getOwnerDetails);

//**
// get top sellers
router.get('/getTopSellers',
  getTopSellersValidator,
  validate,
  userController.getTopSellers);

//**
// get top buyers
router.get('/getTopBuyers',
  getTopBuysValidator,
  validate,
  userController.getTopBuyers);



export default router;
