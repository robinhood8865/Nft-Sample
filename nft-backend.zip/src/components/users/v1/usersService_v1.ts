import { GeneralError } from '../../../utils/errors';
import { IUser } from '../../../types/users.types';
import { User } from '../userDal';


const getUserProfile = async (data: { publicAddress: string }): Promise<IUser | null> => {
  const { publicAddress } = data;
  const user: any = await User.findOne({ publicAddress }).select('nonce');
  return user;
};

const getUserById = async (data: { _id: string }): Promise<IUser | null> => {
  const { _id } = data;
  const user: any = await User.findById(_id);
  return user;
};

const updateNonce = async (data: { publicAddress: string, nonce: number }): Promise<IUser | null> => {
  const { publicAddress, nonce } = data;
  const user: any = await User.findOneAndUpdate({ publicAddress }, { nonce });
  return user;
};

const getOwnerDetails = async (data: { publicAddress: string }): Promise<IUser | null> => {
  const { publicAddress } = data;

  const user: any = await User.findOne({ publicAddress });

  if (!user) {
    throw new Error(`not user with address ${publicAddress}`);
  }
  return user;

};

const createUser = async (data: IUser): Promise<IUser> => {
  const user = new User(data);
  const _user = await user.save();
  return _user;
};

const updateUser = async (data: IUser): Promise<IUser> => {
  const profileFields = [
    'publicAddress',
    'firstName',
    'lastName',
    'username',
    'profileImage',
    'bannerImage',
    'email',
    'bio',
    'twitter',
    'youtube',
    'discord',
    'facebook',
    'ticktok',
    'snapchat',
    'website',
  ];

  const updatedUser: any = {};
  profileFields.forEach((field) => {
    const value = data[field as keyof typeof data];
    if (value) {
      updatedUser[field] = value;
    }
  });

  const { publicAddress } = data;
  const user: any = await User.findOneAndUpdate(
    { publicAddress },
    updatedUser,
    { new: true, useFindAndModify: false },
  );
  if (!user) {
    throw new GeneralError(`User with address ${publicAddress} doesn't exists`);
  }
  return user;
};

const searchUsers = async (
  match: string,
  pageLimit?: number,
  currentPage?: number,
): Promise<any> => {
  const _currentPage = currentPage || 0;

  // It should as least have limit
  if (pageLimit) {
    return User.aggregate([
      {
        $match: { username: { $regex : `.*${match}.*`, $options: 'i' } },
      }, {
        $facet: {
          data: [
            { $skip: _currentPage as number * pageLimit },
            { $limit: pageLimit },
          ],
          pagination: [{ $count: 'totalCount' }],
        },
      }, {
        $unwind: "$pagination",
      },
    ]);
  } else {
    return [];
  }
};

const userService = {
  getUserProfile,
  getUserById,
  updateNonce,
  createUser,
  updateUser,
  getOwnerDetails,
  searchUsers,
};

export default userService;
