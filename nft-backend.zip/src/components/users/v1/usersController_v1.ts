import { Response, NextFunction } from 'express';
import processTrackingService from '../../processTracking/v1/processTrackingService_v1';
import logger from '../../../utils/logger';
// import { getPublicImageLink } from '../../../utils/utils';
// import s3Upload from '../../../utils/s3Upload.service';
// import { IStaticContent } from '../../../types/staticContent.types';
// import { IMAGES_NAMES, LUTS } from '../../../utils/enums';
import userService from './usersService_v1';
import { ONE_DAY, PROCESS_TRAKING_ACTION, PROCESS_TRAKING_STATUS } from '../../../utils/enums';

const createUser = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  // const { creatorAddress, ownerAddress, tokenId, title, description, imageUrl, marketType, price } = req.body;

  try {
    const newUser: any = await userService.createUser(req.body);
    res.send(newUser);
  } catch (error) {
    logger.error('error in createUser', error);
    next(error);
  }
};

const getUserN = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  const { publicAddress } = req.query;
  try {
    const user: any = await userService.getUserProfile({ publicAddress });

    res.send(user);
  } catch (error) {
    logger.error('error in getUserProfile', error);
    next(error);
  }
};

const getUserById = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  const { _id } = req.query;
  try {
    const user: any = await userService.getUserById({ _id });

    res.send(user);
  } catch (error) {
    logger.error('error in getUserById', error);
    next(error);
  }
};

const updateUser = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  try {
    const newUser: any = await userService.updateUser(req.body);
    res.send(newUser);
  } catch (error) {
    logger.error('error in updateUser', error);
    next(error);
  }
};

const getOwnerDetails = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  const { publicAddress } = req.query;

  try {
    const user: any = await userService.getOwnerDetails({ publicAddress });

    res.send(user);
  } catch (error) {
    logger.error('error in getOwnerDetails', error);
    next(error);
  }
};


const getTopSellers = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  const { limit, day } = req.query;
  try {
    const timestamp = new Date().getTime() - ONE_DAY * day;
    const date = new Date(timestamp);

    const topSellers = await processTrackingService.getTopSellers({
      processStatus: PROCESS_TRAKING_STATUS.AFTER,
      actions: [
        PROCESS_TRAKING_ACTION.BUY_SIMPLE_SINGLE,
        PROCESS_TRAKING_ACTION.BUY_SIMPLE_MULTIPLE,
        PROCESS_TRAKING_ACTION.TERMINATE_AUCTION_SOLD,
      ],
      limit,
      date,
    });
    res.send(topSellers);
  } catch (error) {
    logger.error('error in getTopSellers', error);
    next(error);
  }
};


const getTopBuyers = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  const { limit, day } = req.query;

  try {
    const timestamp = new Date().getTime() - ONE_DAY * day;
    const date = new Date(timestamp);

    const topBuyers = await processTrackingService.getTopBuyers({
      processStatus: PROCESS_TRAKING_STATUS.AFTER,
      actions: [
        PROCESS_TRAKING_ACTION.BUY_SIMPLE_SINGLE,
        PROCESS_TRAKING_ACTION.BUY_SIMPLE_MULTIPLE,
        PROCESS_TRAKING_ACTION.TERMINATE_AUCTION_SOLD,
      ],
      limit,
      date,
    });
    res.send(topBuyers);
  } catch (error) {
    logger.error('error in getTopBuyers', error);
    next(error);
  }
};


const userController = {
  getUserN,
  getUserById,
  createUser,
  updateUser,
  getOwnerDetails,
  getTopSellers,
  getTopBuyers,
};

export default userController;
