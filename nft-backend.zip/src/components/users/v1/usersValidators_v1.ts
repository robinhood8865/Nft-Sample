/* eslint-disable indent */

import {
  body,
  query,
} from 'express-validator';
import { Response } from 'express';
import { DEFAULT_TIMEFRAME } from '../../../utils/enums';

export const getUserNValidator = [
  query('publicAddress', 'Not valid address')
    .isLength({ min: 10 }),
];
export const getUserByIdValidator = [
  query('_id').isLength({ min: 10 }),
];

export const getTopSellersValidator = [
  query('limit', 'Limit is not valid').default(10).isInt().toInt(),
  query('day', 'Day is not valid').default(DEFAULT_TIMEFRAME.THIRTY).isInt().toInt(),
];

export const getTopBuysValidator = [
  query('limit', 'Limit is not valid').default(10).isInt().toInt(),
  query('day', 'Day is not valid').default(DEFAULT_TIMEFRAME.THIRTY).isInt().toInt(),
];

export const updateUserValidator = [
  body('publicAddress').isString().notEmpty(),
  body('username').isString().optional(),
  body('firstName').isString().optional(),
  body('lastName').isString().optional(),
  body('profileImage').isString().optional(),
  body('bannerImage').isString().optional(),
  body('bio').isString().optional(),
  body('email').isEmail().optional(),
  body('twitter').isString().optional(),
  body('youtube').isString().optional(),
  body('discord').isString().optional(),
  body('facebook').isString().optional(),
  body('ticktok').isString().optional(),
  body('snapchat').isString().optional(),
  body('website').isString().optional(),
];

export const isRightUser = (req: any, res: Response, next: any) => {
  try {
    const { user, body } = req;
    if (!user?.payload?.publicAddress) {
      throw new Error('invalid request');
    }
    
    const { publicAddress } = user?.payload;
    if (publicAddress.toLowerCase() !== body.publicAddress) {
      throw new Error('access limited');
    }
    next();
  } catch (err) {
    res.status(401).send('invalid user');
  }
};
