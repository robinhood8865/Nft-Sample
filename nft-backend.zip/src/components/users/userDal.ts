import mongoose, { Document } from 'mongoose';
import { IUser } from '../../types/users.types';

const UserSchema = new mongoose.Schema(
  {
    nonce: {
      type: Number,
      default: Math.floor(Math.random() * 1000000), // Initialize with a random }
    },
    publicAddress: {
      type: String,
      unique: true,
      lowercase: true,
    },
    firstName: {
      type: String,
    },
    lastName: {
      type: String,
    },
    username: {
      type: String,
    },
    profileImage: {
      type: String,
    },
    bannerImage: {
      type: String,
    },
    email: {
      type: String,
    },
    bio: {
      type: String,
    },
    twitter: {
      type: String,
    },
    youtube: {
      type: String,
    },
    discord: {
      type: String,
    },
    facebook: {
      type: String,
    },
    snapchat: {
      type: String,
    },
    ticktok: {
      type: String,
    },
    website: {
      type: String,
    },
  },
  { timestamps: true },
);

export const User = mongoose.model<IUser & Document>('User', UserSchema);
