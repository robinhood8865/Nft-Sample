import { EventEmitter } from 'events';
const eventEmitter = new EventEmitter();

type EventFirer = (event: any) => void;
type EventHandler = (event: any) => void;

const fireEvent: EventFirer = (event: any) => {
  eventEmitter.emit('data', event);
};

const subscribe: EventHandler = (listener: EventHandler) => {
  eventEmitter.on('data', (evt: any) => listener(evt));
};

export default Object.freeze({
  fireEvent,
  subscribe,
});
