import express from 'express';
import { addClient } from './eventsController_v1';

const router = express.Router();

router.get('/', addClient);

export default router;