import { RequestHandler, Response } from 'express';
import eventPool from './eventService_v1';

interface IClient {
  id: number;
  res: Response;
}
let clients: IClient[] = [];

export const addClient: RequestHandler = (req, res) => {
  const headers = {
    'Content-Type': 'text/event-stream',
    'Connection': 'keep-alive',
    'Cache-Control': 'no-cache',
  };
  const data = `data: welcome\n\n`;
  const clientId = Date.now();
  const newClient: IClient = { id: clientId, res };

  clients.push(newClient);
  res.writeHead(200, headers);
  res.write(data);
  req.on('close', () => {
    console.log(`${clientId} Connection closed`);
    clients = clients.filter((client) => client.id !== clientId);
  });
};

eventPool.subscribe((event: any) => {
  // console.log('captured data', event);
  clients.forEach(({ res }) => {
    res.write(`data: ${JSON.stringify(event)}\n\n`);
    res.flush();
  });
});

