import mongoose, { Document } from 'mongoose';
import mongoosePaginate from 'mongoose-paginate-v2';
import { INft } from '../../types/nfts.types';
import { MARKET_TYPE, STATUS } from '../../utils/enums';

const NftSchema = new mongoose.Schema(
  {
    transactionHash: {
      type: String,
      // required: true,
    },
    tokenId: {
      type: String,
      // required: true,
    },
    creatorAddress: {
      type: String,
      // required: true,
      lowercase: true,
    },
    ownerAddress: {
      type: String,
      // required: true,
      lowercase: true,
    },
    category: {
      type: String,
    },
    royalty: {
      type: Number,
      default: 0,
    },
    marketType: {
      type: String,
      enum: [MARKET_TYPE.SIMPLE, MARKET_TYPE.AUCTION],
    },
    attributes: {
      type: Array,
      default: [],
    },
    status: {
      type: String,
      enum: [STATUS.ON_SELL, STATUS.NOT_LISTED],
    },
    imageUrl: {
      type: String,
    },
    previewImageUrl: {
      type: String,
    },
    listingId: {
      type: String,
    },
    deadline: {
      type: String,
    },
    collectionId: {
      type: String,
    },
    nftAddress: {
      type: String,
      lowercase: true,
    },
    networkId: {
      type: Number,
    },
    totalAmount: {
      type: Number,
      default: 0,
    },
    leftAmount: {
      type: Number,
      default: 0,
    },
    listedAmount: {
      type: Number,
      default: 0,
    },
    multiple: {
      type: Boolean,
      default: false,
    },
    name: {
      type: String,
      // required: true,
    },
    description: {
      type: String,
    },
    price: {
      type: Number,
    },
    minimumBid: {
      type: String,
    },
    priceTokenType: {
      type: String,
    },
    expirationDate: {
      type: Date,
    },
    listedAt: {
      type: Date,
    },
    isListedOnce: {
      type: Boolean,
      default: false,
    },
    likes: {
      type: Number,
      default: 0,
    },
    views: {
      type: Number,
      default: 0,
    },
    flag: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true }, // So `res.json()` and other `JSON.stringify()` functions include virtuals
    toObject: { virtuals: true },
  },
);

NftSchema.virtual('owner', {
  ref: 'User',
  localField: 'ownerAddress',
  foreignField: 'publicAddress',
});

NftSchema.virtual('creator', {
  ref: 'User',
  localField: 'creatorAddress',
  foreignField: 'publicAddress',
});

NftSchema.virtual('nftCollection', {
  ref: 'NftCollection',
  localField: 'collectionId',
  foreignField: 'id',
});

NftSchema.virtual('priceToken', {
  ref: 'PriceToken',
  localField: 'priceTokenType',
  foreignField: 'name',
});

NftSchema.plugin(mongoosePaginate);

export const Nft = mongoose.model<INft & Document>('Nft', NftSchema);
