import { body, query } from 'express-validator';
import { MARKET_TYPE, SORT_ORDER, STATUS } from '../../../utils/enums';

export const createNftValidator = [
  body('tokenId', 'tokenId is not valid').isString(),
  body('creatorAddress', 'Creator address is not valid').isString(),
  body('ownerAddress', 'Owner address is not valid').isString(),
  body('category', 'category is not valid').isString().optional(),
  body('royalty', 'Royalty is not valid').isNumeric().toFloat().optional(),
  body('collectionId', 'CollectionId is not valid').isString().optional(),
  body('marketType', 'Market type is not valid')
    .isIn([MARKET_TYPE.AUCTION, MARKET_TYPE.SIMPLE, MARKET_TYPE.MORE])
    .optional(),
  body('attributes', 'Attributes is not valid').isArray().optional(),
  body('status', 'Status is not valid')
    .isIn([STATUS.NOT_LISTED, STATUS.ON_SELL]),
  body('imageUrl', 'Image is not valid').isString(),
  body('listingId', 'Listing Id is not valid').isString().optional(),
  body('deadline', 'Deadline is not valid').isString().optional(),
];

export const getNftsValidator = [
  query('currentPage', 'Current page is not valid.').isInt().toInt(),
  query('pageLimit', 'Page limit is not valid').isInt().toInt(),
  query('filters', 'Filters are not valid')
    .isArray()
    .optional()
    .customSanitizer((filters: string[]) => filters.map(filter => {
      try {
        const parsed = JSON.parse(filter);
        return parsed;
      } catch (error) {
        return {};  
      }
    }))
    .custom((filters: any[]) => {
      const length = filters.length;

      for (let i = 0; i < length; i++) {
        // eslint-disable-next-line security/detect-object-injection
        const filter = filters[i] || {};
        const { left, op, right } = filter;
        if (!left || !op || !right) {
          return false;
        }
      }
      return true;
    }),
  query('sortOrder', 'Sort order is not valid').isIn([
    SORT_ORDER.AUCTION_ENDING_SOON,
    SORT_ORDER.PRICE_HIGH_TO_LOW,
    SORT_ORDER.PRICE_LOW_TO_HIGH,
    SORT_ORDER.RECENTLY_ADDED,
  ]),
];

export const getMyNftsValidator = [
  query('ownerAddress').isString().optional(),
  query('status').isIn([STATUS.NOT_LISTED, STATUS.ON_SELL]).optional(),
  query('creatorAddress').isString().optional(),
];

export const getNftDetailValidator = [
  query('tokenId').isString(),
  query('nftAddress').isString(),
];

export const getNftsByCollectionIdValidator = [
  query('collectionId').isString(),
];

export const getNftHistoryValidator = [
  query('tokenId').isString(),
  query('nftAddress').isString(),
];