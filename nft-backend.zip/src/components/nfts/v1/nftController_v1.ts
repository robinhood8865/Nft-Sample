/* eslint-disable @typescript-eslint/no-var-requires */
import { Request, Response, NextFunction } from 'express';
import moment from 'moment';
import config from 'config';
import axios, { AxiosRequestConfig } from 'axios';
import FormData from 'form-data';
import { PROCESS_TRAKING_ACTION, PROCESS_TRAKING_STATUS, STATUS, MARKET_TYPE } from '../../../utils/enums';
import logger from '../../../utils/logger';
// import { getPublicImageLink } from '../../../utils/utils';
// import s3Upload from '../../../utils/s3Upload.service';
// import { IStaticContent } from '../../../types/staticContent.types';
// import { IMAGES_NAMES, LUTS } from '../../../utils/enums';
import processTrackingService from '../../processTracking/v1/processTrackingService_v1';
import nftService from './nftService_v1';

const createNft = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  try {
    //* find on mongo id nft exist, to make sure the it saved only once on the db
    const { transactionHash, data } = req.body;
    console.log('🚀 ~ file: nftController_v1.ts ~ line 20 ~ createNft ~ data', data);
    const existedNft = await nftService.getNftByTransactionHashAndFlag({ transactionHash, flag: true });

    if (existedNft) {
      console.log('existedNft!!!');
      res.send('existedNft');
    }

    const newNFT: any = await nftService.updateNft({ transactionHash }, { ...data, flag: true });
    console.log('🚀 ~ file: nftController_v1.ts ~ line 28 ~ createNft ~ newNFT', newNFT);
    res.send(newNFT);
  } catch (error) {
    logger.error('error in createNft', error);
    next(error);
  }
};

// const createNft = async (req: any, res: Response, next: NextFunction): Promise<void> => {
//   try {
//     const { tokenURI, creator, amount, royalty, startPrice, deadline, frontData, transactionHash } = req.body;
//     const { name, description, imageUrl, previewImageUrl, attributes, multiple, collectionId, category } = frontData;
//     //* find on mongo id nft exist, to make sure the it saved only once on the db
//     const existedNft = await nftService.getNftByTransactionHashAndFlag({ transactionHash, flag: true });

//     if (existedNft) {
//       console.log('existedNft!!!');
//       return;
//     }

//     const _attributes = attributes.map((item: any) => {
//       return {
//         display_type: item.display_type,
//         trait_type: item.trait_type,
//         value: item.value,
//       };
//     });

//     //** mongo item */
//     const nftToCreate: any = {
//       tokenURI,
//       name: name,
//       description: description,
//       imageUrl: imageUrl,
//       previewImageUrl: previewImageUrl,
//       attributes: _attributes,
//       creatorAddress: creator,
//       ownerAddress: creator,
//       collectionId,
//       royalty,
//       multiple,
//       category: category,
//       isListedOnce: false,
//       status: STATUS.NOT_LISTED,
//       totalAmount: amount,
//       leftAmount: amount,
//       listedAmount: 0,
//       flag: true,
//     };

//     // * create mongo row
//     const newNft: any = await nftService.updateNft({ transactionHash }, nftToCreate);
//     console.log(newNft, "======");

//     const getAction = () => {
//       if (multiple) {
//         return PROCESS_TRAKING_ACTION.CREATE_SIMPLE_MULTIPLE;
//       }
//       if (startPrice > 0) {
//         return PROCESS_TRAKING_ACTION.CREATE_AUCTION;
//       }
//       return PROCESS_TRAKING_ACTION.CREATE_SIMPLE_SINGLE;
//     };

//     // ** create proccess tracking */
//     await processTrackingService.createTracking({
//       ...nftToCreate,
//       transactionHash,
//       userAddress: creator,
//       networkId: newNft.networkId,
//       action: getAction(),
//       processStatus: PROCESS_TRAKING_STATUS.AFTER,
//     });

//     //* fire event
//     // eventPool.fireEvent({
//     //   eventName,
//     //   ...res.toObject(),
//     // });

//     res.send(newNft);
//   } catch (error) {
//     logger.error('error in createNft', error);
//     next(error);
//   }
// };

// const createNftForSimpleItemCreate = async (req: any, res: Response, next: NextFunction): Promise<void> => {
//   try {
//     const { nftContract, tokenId, tokenURI, price, creator, sellerAddress, quantity, royalty, frontData, transactionHash } = req.body;
//     const priceInEth = Web3.utils.fromWei(price.toString(), "ether");
//     const { name, description, imageUrl, previewImageUrl, attributes, multiple, collectionId, category } = frontData;

//     //* find on mongo id nft exist, to make sure the it saved only once on the db
//     const existedItem = await nftService.getNftByTransactionHashAndFlag({ transactionHash, flag: true });

//     if (existedItem) {
//       console.log('existedItem!!!');
//       return;
//     }

//     const _attributes = attributes.map((item: any) => {
//       return {
//         display_type: item.display_type,
//         trait_type: item.trait_type,
//         value: item.value,
//       };
//     });

//     const sellerNftBalance = await getUserNftQuantityFromNftContract({
//       nftContract,
//       userAddress: sellerAddress,
//       tokenId: Number(tokenId),
//     });

//     //** mongo item */
//     const nftToCreate: any = {
//       // listingId,
//       tokenId,
//       price: priceInEth,
//       tokenURI,
//       // transactionHash,
//       name,
//       description,
//       imageUrl,
//       previewImageUrl,
//       attributes: _attributes,
//       creatorAddress: creator,
//       ownerAddress: sellerAddress,
//       // nftAddress: nftContractAddress,
//       collectionId,
//       royalty,
//       marketType: MARKET_TYPE.SIMPLE,
//       status: STATUS.ON_SELL,
//       isListedOnce: true,
//       multiple,
//       // networkId,
//       category,
//       totalAmount: Number(sellerNftBalance) + Number(quantity),
//       leftAmount: Number(sellerNftBalance),
//       listedAmount: Number(quantity),
//       flag: true,
//     };

//     // * create mongo row
//     const newNft: any = await nftService.updateNft({ transactionHash }, nftToCreate);

//     // ** create proccess tracking */
//     await processTrackingService.createTracking({
//       ...nftToCreate,
//       transactionHash,
//       nftAddress: newNft.nftAddress,
//       userAddress: sellerAddress,
//       networkId,
//       action: multiple ? PROCESS_TRAKING_ACTION.LIST_SIMPLE_MULTIPLE : PROCESS_TRAKING_ACTION.LIST_SIMPLE_SINGLE,
//       processStatus: PROCESS_TRAKING_STATUS.AFTER,
//     });

//     res.send(newNft);
//   } catch (error) {
//     logger.error('error in createNft', error);
//     next(error);
//   }
// };

// const getNftByTokenAndOwnerAddress = async (req: any, res: Response, next: NextFunction): Promise<void> => {
//   const { tokenId, ownerAddress } = req.query;
//   try {
//     const nft: any = await nftService.getNftByTokenAndOwnerAddress({ tokenId, ownerAddress });
//     res.send(nft);
//   } catch (error) {
//     logger.error('error in getNftByTokenAndOwnerAddress', error);
//     next(error);
//   }
// };

// const updateNft = async (req: any, res: Response, next: NextFunction): Promise<void> => {
//   // const { creatorAddress, ownerAddress, tokenId, title, description, imageUrl, marketType, price } = req.body;

//   try {
//     const newNft: any = await nftService.updateNft(req.body);
//     res.send(newNft);
//   } catch (error) {
//     logger.error('error in updateNft', error);
//     next(error);
//   }
// };
const empty = { data: [], pagination: { totalCount: 0 } };

const getNfts = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  // const { collectionId } = req.query;
  try {
    const nfts = await nftService.getNftList(req.query);

    res.send(nfts.length ? nfts[0] : empty);
  } catch (error) {
    logger.error('error in getNfts', error);
    next(error);
  }
};

const getNftHistory = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  const { tokenId, nftAddress } = req.query;

  try {
    // *
    const topCollections = await processTrackingService.getNftHistory({
      tokenId,
      nftAddress,
      processStatus: PROCESS_TRAKING_STATUS.AFTER,
      actions: [
        PROCESS_TRAKING_ACTION.BUY_SIMPLE_SINGLE,
        PROCESS_TRAKING_ACTION.TERMINATE_AUCTION_SOLD,
        PROCESS_TRAKING_ACTION.CREATE_AUCTION,
        PROCESS_TRAKING_ACTION.CREATE_SIMPLE_SINGLE,
      ],
    });
    // *
    // const nfts = await nftService.getNftHistory({ tokenId, nftAddress }); // not working well because i aggregate by owner address, what happen ih the user buy again?

    res.send(topCollections);
  } catch (error) {
    logger.error('error in getNftHistory', error);
    next(error);
  }
};

// const getCollectibleNfts = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
//   try {
//     const nfts = await nftService.getCollectibleNfts();
//     res.send(nfts);
//   } catch (error) {
//     logger.error('error in getCollectibleNfts', error);
//     next(error);
//   }
// };

const getMyNfts = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  try {
    const nfts = await nftService.getMyNfts(req.query);
    res.send(nfts);
  } catch (error) {
    logger.error('error in getMyNfts', error);
    next(error);
  }
};

const getNftDetailes = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  const { tokenId, nftAddress } = req.query;

  try {
    const nft = await nftService.getNftDetailes({ tokenId, nftAddress });
    res.send(nft);
  } catch (error) {
    logger.error('error in getNftDetailes', error);
    next(error);
  }
};

const nftMultipleDetailes = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  const { tokenId, nftAddress } = req.query;

  try {
    const nft = await nftService.nftMultipleDetailes({ tokenId, nftAddress });
    res.send(nft);
  } catch (error) {
    logger.error('error in nftMultipleDetailes', error);
    next(error);
  }
};

const getNftsByCollectionId = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  const { collectionId } = req.query;

  try {
    const nft = await nftService.getNftsByCollectionId({ collectionId });
    res.send(nft);
  } catch (error) {
    logger.error('error in getNftsByCollectionId', error);
    next(error);
  }
};

const getHotAuctions = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  try {
    const nft = await nftService.getHotAuctions();
    res.send(nft);
  } catch (error) {
    logger.error('error in getHotAuctions', error);
    next(error);
  }
};

const getCountByCategory = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  try {
    const result: { [key: string]: any } = {};
    const data = await nftService.getNftCountByCategory();
    data.forEach((category: any) => {
      const { name, count } = category;
      if (name) {
        result[name] = count;
      }
    });

    res.send(result);
  } catch (error) {
    logger.error('error in getCountByCategory', error);
    next(error);
  }
};

// const setMarketContractId = async (req: any, res: Response, next: NextFunction): Promise<void> => {
//   const { mongoId, marketContractId, } = req.body;
//   try {
//     const nft = await nftService.setMarketContractId({ mongoId, marketContractId, });
//     res.send(nft);
//   } catch (error) {
//     logger.error('error in setMarketContractId', error);
//     next(error);
//   }
// };

const pinata = axios.create({ baseURL: 'https://api.pinata.cloud/pinning' });
pinata.interceptors.request.use((axiosConfig: AxiosRequestConfig) => {
  axiosConfig.headers = {
    ...axiosConfig.headers,
    pinata_api_key: process.env.PINATA_APIKEY || (config.get('PINATA_API_KEY') as string),
    pinata_secret_api_key: process.env.PINATA_SECRET_API_KEY || (config.get('PINATA_SECRET_API_KEY') as string),
  };
  return axiosConfig;
});

interface PinataResponse {
  data: {
    IpfsHash: string;
  };
}

const getImageUri = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.file) {
      next('Invalid File');
    } else {
      const data = new FormData();
      const file = req.file;
      const createdAt = moment.now();
      const fileName = file.originalname + createdAt;

      data.append('title', fileName);
      data.append('file', file.buffer, { filename: fileName, contentType: file.mimetype });
      const metadata = JSON.stringify({
        name: fileName,
        keyvalues: {
          size: file.size,
        },
      });
      data.append('pinataMetadata', metadata);

      const result: PinataResponse = await pinata.post('/pinFileToIPFS', data, {
        maxContentLength: -1,
        headers: {
          'Content-Type': `multipart/form-data; boundary=${data.getBoundary()}`,
        },
      });
      res.send(`ipfs://${result.data.IpfsHash}`);
    }
  } catch (error) {
    logger.error('error in getImageUri', error);
    next(error);
  }
};

const getUri = async (req: any, res: Response, next: NextFunction): Promise<void> => {
  try {
    const result: PinataResponse = await pinata.post('/pinJSONToIPFS', req.body);
    res.send(`ipfs://${result.data.IpfsHash}`);
  } catch (error) {
    logger.error('error in getUri', error);
    next(error);
  }
};

const nftController = {
  createNft,
  // getCollectibleNfts,
  getNftsByCollectionId,
  // sellNft,
  // updateNft,
  getNfts,
  getMyNfts,
  getNftDetailes,
  nftMultipleDetailes,
  getNftHistory,
  getHotAuctions,
  getCountByCategory,
  // getNftByTokenAndOwnerAddress,
  getImageUri,
  getUri,
};

export default nftController;
