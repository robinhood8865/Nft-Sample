import express from 'express';
import multer from 'multer';
import nftController from './nftController_v1';
// import { hasRole } from '../../middleware/auth'; // authentication to all routes
// import { USER_ROLES } from '../../utils/enums';

import { validate } from '../../../middleware/validators';
import {
  getMyNftsValidator,
  getNftDetailValidator,
  getNftHistoryValidator,
  getNftsByCollectionIdValidator,
  getNftsValidator,
} from './nftValidators_v1';

// import { IMAGES_NAMES } from '../../../utils/enums';

const router = express.Router();
// const upload = multer({ dest: 'uploads/' });

//**
// create nft
router.post('/', nftController.createNft);

//**
// get nfts
router.get('/', getNftsValidator, validate, nftController.getNfts);

// //**
// // get Collectible Nfts
// router.get('/getCollectibleNfts',
//   // validations
//   // getStaticContentsByHospitalCodeValidator,
//   validate,
//   nftController.getCollectibleNfts);

//**
// upfate nfts
// router.put('/',
//   // validations
//   // getStaticContentsByHospitalCodeValidator,
//   validate,
//   nftController.updateNft);

//**
// get My Nfts
router.get('/getMyNfts', getMyNftsValidator, validate, nftController.getMyNfts);
//**
// get Nft By Token And OwnerAddress
// router.get('/getNftByTokenAndOwnerAddress',
//   // validations
//   // getStaticContentsByHospitalCodeValidator,
//   validate,
//   nftController.getNftByTokenAndOwnerAddress);

//**
// get Nft Detailes
router.get('/getNftDetailes', getNftDetailValidator, validate, nftController.getNftDetailes);

//**
// get Nft multiple Detailes
router.get('/nftMultipleDetailes', getNftDetailValidator, validate, nftController.nftMultipleDetailes);

//**
// get Nft Detailes
router.get('/getNftsByCollectionId', getNftsByCollectionIdValidator, validate, nftController.getNftsByCollectionId);

//**
// get Nft Detailes
router.get('/getNftHistory', getNftHistoryValidator, validate, nftController.getNftHistory);

router.get('/getHotAuctions', nftController.getHotAuctions);

router.get('/getCountByCategory', nftController.getCountByCategory);

//**
// set marketContract id
// router.put('/setMarketContractId',
//   // validations
//   // getStaticContentsByHospitalCodeValidator,
//   validate,
//   nftController.setMarketContractId);

router.post('/getImageUri',
  multer({ storage: multer.memoryStorage() }).single('file'),
  nftController.getImageUri);

router.post('/getUri',
  nftController.getUri);

export default router;
