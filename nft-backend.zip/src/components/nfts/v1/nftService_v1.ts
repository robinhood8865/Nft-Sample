/* eslint-disable security/detect-object-injection */
import { MARKET_TYPE, STATUS, SORT_ORDER } from '../../../utils/enums';
import { INft, INftFilter, FilterOperator } from '../../../types/nfts.types';
import { Nft } from '../nftDal';
import { GeneralError } from '../../../utils/errors';

const createNft = async (data: INft): Promise<INft> => {
  const nft = new Nft(data);
  const _nft = await nft.save();
  return _nft;
};

const updateNft = async (filter: any, data: INft): Promise<any> => {
  let _nft = await Nft.findOneAndUpdate(filter, data);
  _nft = await Nft.findOne(filter);
  return _nft;
};

const getNftByTransactionHash = async (data: { transactionHash: string }): Promise<INft> => {
  const { transactionHash } = data;
  const bid: any = await Nft.findOne({ transactionHash }).populate('buyer').sort({ createdAt: -1 });
  return bid;
};

const getNftList = async (data: any): Promise<any> => {
  const { currentPage, pageLimit, filters, sortOrder, search } = data;
  const _currentPage = currentPage || 0;
  let match: { [key: string]: any } = {};
  let sort: { [key: string]: any } = {};

  // we should have at least valid pageLimit
  if (!pageLimit) {
    return [];
  }

  filters?.forEach((filter: INftFilter) => {
    const { left, op, right } = filter;
    if (op == FilterOperator.Equals) {
      match[left] = right;
    } else if (op == FilterOperator.InArray) {
      match[left] = { $in: right };
    } else if (op == FilterOperator.GreaterThanEqual) {
      const prev = match[left] ? match[left] : {};
      match[left] = { ...prev, $gte: Number.parseFloat(right.toString()) };
    } else if (op == FilterOperator.LessThanEqual) {
      const prev = match[left] ? match[left] : {};
      match[left] = { ...prev, $lte: Number.parseFloat(right.toString()) };
    }
  });

  switch (sortOrder) {
    case SORT_ORDER.RECENTLY_ADDED:
      sort = { createdAt: -1 };
      break;
    case SORT_ORDER.PRICE_HIGH_TO_LOW:
      sort = { price: -1 };
      break;
    case SORT_ORDER.PRICE_LOW_TO_HIGH:
      sort = { price: 1 };
      break;
    case SORT_ORDER.AUCTION_ENDING_SOON:
      match.marketType = MARKET_TYPE.AUCTION;
      // match.expirationDate = { $gte: new Date() };
      sort = { expirationDate: -1 };
      break;
    default:
      sort = { createdAt: -1 };
      break;
  }

  // we should convert the match to [{ $and: [..., { $or: [...] }] }]
  if (search) {
    const newMatch: { $and: any[] } = { $and: [] };

    Object.keys(match).forEach((key: string) => {
      newMatch.$and.push({ [key]: match[key] });
    });
    newMatch.$and.push({
      $or: [
        { name: { $regex: `.*${search}.*`, $options: 'i' } },
        { description: { $regex: `.*${search}.*`, $options: 'i' } },
      ],
    });

    match = newMatch;
  }

  const nfts: any = Nft.aggregate([
    {
      $group: {
        _id: { tokenId: '$tokenId', nftAddress: '$nftAddress', ownerAddress: '$ownerAddress' },
        mongoId: { $last: '$_id' },
        createdAt: { $last: '$createdAt' },
        tokenId: { $last: '$tokenId' },
        expirationDate: { $last: '$expirationDate' },
        creatorAddress: { $last: '$creatorAddress' },
        ownerAddress: { $last: '$ownerAddress' },
        nftAddress: { $last: '$nftAddress' },
        multiple: { $last: '$multiple' },
        collectionId: { $last: '$collectionId' },
        totalAmount: { $last: '$totalAmount' },
        leftAmount: { $last: '$leftAmount' },
        listedAmount: { $last: '$listedAmount' },
        category: { $last: '$category' },
        royalty: { $last: '$royalty' },
        marketType: { $last: '$marketType' },
        status: { $last: '$status' },
        imageUrl: { $last: '$imageUrl' },
        previewImageUrl: { $last: '$previewImageUrl' },
        listingId: { $last: '$listingId' },
        deadline: { $last: '$deadline' },
        name: { $last: '$name' },
        description: { $last: '$description' },
        price: { $last: '$price' },
        networkId: { $last: '$networkId' },
        minimumBid: { $min: '$minimumBid' },
        listedAt: { $last: '$listedAt' },
        isListedOnce: { $last: '$isListedOnce' },
      },
    },
    {
      $lookup: {
        from: 'users',
        localField: 'ownerAddress',
        foreignField: 'publicAddress',
        as: 'owner',
      },
    },
    {
      $lookup: {
        from: 'nftcollections',
        localField: 'collectionId',
        foreignField: 'id',
        as: 'nftCollection',
      },
    },
    {
      $lookup: {
        from: 'bids',
        localField: 'listingId',
        foreignField: 'listingId',
        as: 'bids',
      },
    },
    {
      $sort: sort,
    },
    {
      $match: match,
    },
    {
      $facet: {
        data: [{ $skip: _currentPage * pageLimit }, { $limit: pageLimit }],
        pagination: [{ $count: 'totalCount' }],
      },
    },
    {
      $unwind: '$pagination',
    },
  ]);

  return nfts;
};

const getNfts = async (data: any): Promise<any> => {
  // const nft: any = await Nft.findOne({ tokenId })
  const { currentPage, pageLimit } = data;

  const nfts: any = Nft.aggregate([
    { $sort: { createdAt: 1 } },
    {
      $group: {
        _id: { tokenId: '$tokenId', nftAddress: '$nftAddress', ownerAddress: '$ownerAddress' },
        mongoId: { $last: '$_id' },
        createdAt: { $last: '$createdAt' },
        tokenId: { $last: '$tokenId' },
        expirationDate: { $last: '$expirationDate' },
        creatorAddress: { $last: '$creatorAddress' },
        ownerAddress: { $last: '$ownerAddress' },
        nftAddress: { $last: '$nftAddress' },
        multiple: { $last: '$multiple' },
        collectionId: { $last: '$collectionId' },
        totalAmount: { $last: '$totalAmount' },
        leftAmount: { $last: '$leftAmount' },
        listedAmount: { $last: '$listedAmount' },
        category: { $last: '$category' },
        royalty: { $last: '$royalty' },
        marketType: { $last: '$marketType' },
        status: { $last: '$status' },
        imageUrl: { $last: '$imageUrl' },
        listingId: { $last: '$listingId' },
        deadline: { $last: '$deadline' },
        name: { $last: '$name' },
        description: { $last: '$description' },
        price: { $last: '$price' },
        networkId: { $last: '$networkId' },
        minimumBid: { $min: '$minimumBid' },
        listedAt: { $last: '$listedAt' },
        isListedOnce: { $last: '$isListedOnce' },
      },
    },
    { $match: { status: STATUS.ON_SELL } },
    // limit :20
    // skip:0 // MATCH HAS TO BE HERE AND NOT BEFORE GROUPING
    {
      $lookup: {
        from: 'users',
        localField: 'ownerAddress',
        foreignField: 'publicAddress',
        as: 'owner',
      },
    },
    {
      $lookup: {
        from: 'nftcollections',
        localField: 'collectionId',
        foreignField: 'id',
        as: 'nftCollection',
      },
    },
  ]).facet({
    data: [{ $skip: currentPage * pageLimit }, { $limit: pageLimit }],
    pagination: [{ $count: 'totalCount' }],
  });

  return nfts;
};

const getMyNfts = async (data: { ownerAddress: string; status: string; creatorAddress: string }): Promise<any> => {
  const nfts: any = Nft.aggregate([
    // { $match: data },
    { $sort: { createdAt: 1 } },
    {
      $group: {
        _id: { tokenId: '$tokenId', nftAddress: '$nftAddress' },
        mongoId: { $last: '$_id' },
        createdAt: { $last: '$createdAt' },
        tokenId: { $last: '$tokenId' },
        listingId: { $last: '$listingId' },
        expirationDate: { $last: '$expirationDate' },
        creatorAddress: { $last: '$creatorAddress' },
        ownerAddress: { $last: '$ownerAddress' },
        nftAddress: { $last: '$nftAddress' },
        multiple: { $last: '$multiple' },
        collectionId: { $last: '$collectionId' },
        networkId: { $last: '$networkId' },
        totalAmount: { $last: '$totalAmount' },
        leftAmount: { $last: '$leftAmount' },
        category: { $last: '$category' },
        royalty: { $last: '$royalty' },
        marketType: { $last: '$marketType' },
        status: { $last: '$status' },
        imageUrl: { $last: '$imageUrl' },
        previewImageUrl: { $last: '$previewImageUrl' },
        deadline: { $last: '$deadline' },
        name: { $last: '$name' },
        description: { $last: '$description' },
        price: { $last: '$price' },
        listedAt: { $last: '$listedAt' },
        isListedOnce: { $last: '$isListedOnce' },
        bid: { $last: '$bid' },
        likes: { $last: '$likes' },
        views: { $last: '$views' },
      },
    },
    { $match: data },
    {
      $lookup: {
        from: 'users',
        localField: 'ownerAddress',
        foreignField: 'publicAddress',
        as: 'owner',
      },
    },
    {
      $lookup: {
        from: 'nftcollections',
        localField: 'collectionId',
        foreignField: 'id',
        as: 'nftCollection',
      },
    },
  ]);

  // const nfts: any = await Nft.find(data).populate('owner').populate('creator');
  return nfts;
};

const getNftDetailes = async (data: { tokenId: string; nftAddress: string }): Promise<any> => {
  const { tokenId, nftAddress } = data;

  const nft = await Nft.findOne({ tokenId, nftAddress, multiple: false }, {}, { sort: { createdAt: -1 } })
    .populate('owner')
    .populate('creator')
    .populate('nftCollection')
    .populate('priceToken');

  if (!nft) {
    throw new GeneralError(`not nft with tokenId: ${tokenId} and nftAddress: ${nftAddress}`);
  }
  return nft;
};

const getNftDetailesNoPopulate = async (data: { tokenId: string; nftAddress: string, ownerAddress: string }): Promise<INft> => {
  const { tokenId, nftAddress, ownerAddress } = data;

  const nft = await Nft.findOne({ tokenId, nftAddress, ownerAddress }, {}, { sort: { createdAt: -1 } });

  if (!nft) {
    throw new GeneralError(`not nft with tokenId: ${tokenId} and nftAddress: ${nftAddress}`);
  }
  return nft;
};

const nftMultipleDetailes = async (data: { tokenId: string; nftAddress: string }): Promise<INft[]> => {
  const { tokenId, nftAddress } = data;
  const nft: any = Nft.aggregate([
    { $match: { tokenId, nftAddress, multiple: true } },
    { $sort: { createdAt: 1 } },
    {
      $group: {
        _id: { tokenId: '$tokenId', ownerAddress: '$ownerAddress' }, // {book : '$book',address:'$addr'}
        mongoId: { $last: '$_id' },
        createdAt: { $first: '$createdAt' },
        tokenId: { $last: '$tokenId' },
        listingId: { $last: '$listingId' },
        attributes: { $last: '$attributes' },
        expirationDate: { $last: '$expirationDate' },
        creatorAddress: { $last: '$creatorAddress' },
        ownerAddress: { $last: '$ownerAddress' },
        nftAddress: { $last: '$nftAddress' },
        multiple: { $last: '$multiple' },
        networkId: { $last: '$networkId' },
        collectionId: { $last: '$collectionId' },
        totalAmount: { $last: '$totalAmount' },
        leftAmount: { $last: '$leftAmount' },
        listedAmount: { $last: '$listedAmount' },
        category: { $last: '$category' },
        royalty: { $last: '$royalty' },
        marketType: { $last: '$marketType' },
        status: { $last: '$status' },
        imageUrl: { $last: '$imageUrl' },
        previewImageUrl: { $last: '$previewImageUrl' },
        deadline: { $last: '$deadline' },
        name: { $last: '$name' },
        description: { $last: '$description' },
        price: { $last: '$price' },
        listedAt: { $last: '$listedAt' },
        isListedOnce: { $last: '$isListedOnce' },
        bid: { $last: '$bid' },
        likes: { $last: '$likes' },
        views: { $last: '$views' },
      },
    },

    {
      $lookup: {
        from: 'users',
        localField: 'ownerAddress',
        foreignField: 'publicAddress',
        as: 'owner',
      },
    },
    {
      $lookup: {
        from: 'users',
        localField: 'creatorAddress',
        foreignField: 'publicAddress',
        as: 'creator',
      },
    },
    {
      $lookup: {
        from: 'nftcollections',
        localField: 'collectionId',
        foreignField: 'id',
        as: 'nftCollection',
      },
    },
    // {
    //   $lookup: {
    //     "from": "users",
    //     "localField": "creatorAddress",
    //     "foreignField": "address",
    //     "as": "creator"
    //   }
    // },
    { $sort: { createdAt: 1 } },
  ]);

  // const query: any = {
  //   tokenId
  // }

  // if (ownerAddress) {
  //   query.ownerAddress = ownerAddress
  // }

  // const nft = await Nft.findOne(query).populate('owner').populate('creator');
  return nft;
};

const getNftHistory = async (data: { tokenId: string; nftAddress: string }): Promise<any> => {
  const { tokenId, nftAddress } = data;
  const nft: any = Nft.aggregate([
    { $match: { tokenId, nftAddress } },
    { $sort: { createdAt: 1 } },
    {
      $group: {
        _id: { ownerAddress: '$ownerAddress' }, // {book : '$book',address:'$addr'}
        mongoId: { $last: '$_id' },
        createdAt: { $first: '$createdAt' },
        tokenId: { $last: '$tokenId' },
        listingId: { $last: '$listingId' },
        expirationDate: { $last: '$expirationDate' },
        creatorAddress: { $last: '$creatorAddress' },
        ownerAddress: { $last: '$ownerAddress' },
        nftAddress: { $last: '$nftAddress' },
        multiple: { $last: '$multiple' },
        networkId: { $last: '$networkId' },
        totalAmount: { $last: '$totalAmount' },
        leftAmount: { $last: '$leftAmount' },
        listedAmount: { $last: '$listedAmount' },
        category: { $last: '$category' },
        royalty: { $last: '$royalty' },
        marketType: { $last: '$marketType' },
        status: { $last: '$status' },
        imageUrl: { $last: '$imageUrl' },
        previewImageUrl: { $last: '$previewImageUrl' },
        deadline: { $last: '$deadline' },
        name: { $last: '$name' },
        description: { $last: '$description' },
        price: { $last: '$price' },
        listedAt: { $last: '$listedAt' },
        isListedOnce: { $last: '$isListedOnce' },
        bid: { $last: '$bid' },
        likes: { $last: '$likes' },
        views: { $last: '$views' },
      },
    },

    {
      $lookup: {
        from: 'users',
        localField: 'ownerAddress',
        foreignField: 'publicAddress',
        as: 'owner',
      },
    },
    {
      $lookup: {
        from: 'users',
        localField: 'creatorAddress',
        foreignField: 'publicAddress',
        as: 'creator',
      },
    },
    { $sort: { createdAt: 1 } },
  ]);

  return nft;
};

// const getNftByTokenAndOwnerAddress = async (data: { tokenId: string, ownerAddress: string }): Promise<INft | undefined | null> => {
//   const { tokenId, ownerAddress } = data;
//   const query: any = {
//     tokenId,
//     ownerAddress,
//   };
//   console.log('query', query);

//   const nft = await Nft.findOne(query, {}, { sort: { 'createdAt': -1 } }).populate('owner').populate('creator');
//   return nft;
// };

const getNftsByCollectionId = async (data: { collectionId: string }): Promise<INft[]> => {
  // const { collectionId } = data;
  // const nfts = await Nft.find({ collectionId }).populate('owner').populate('creator');
  // return nfts;
  const nfts: any = Nft.aggregate([
    { $match: data },
    { $sort: { createdAt: 1 } },
    {
      $group: {
        _id: { tokenId: '$tokenId', nftAddress: '$nftAddress' },
        mongoId: { $last: '$_id' },
        createdAt: { $last: '$createdAt' },
        tokenId: { $last: '$tokenId' },
        listingId: { $last: '$listingId' },
        expirationDate: { $last: '$expirationDate' },
        creatorAddress: { $last: '$creatorAddress' },
        ownerAddress: { $last: '$ownerAddress' },
        nftAddress: { $last: '$nftAddress' },
        multiple: { $last: '$multiple' },
        collectionId: { $last: '$collectionId' },
        networkId: { $last: '$networkId' },
        totalAmount: { $last: '$totalAmount' },
        leftAmount: { $last: '$leftAmount' },
        category: { $last: '$category' },
        royalty: { $last: '$royalty' },
        marketType: { $last: '$marketType' },
        status: { $last: '$status' },
        imageUrl: { $last: '$imageUrl' },
        previewImageUrl: { $last: '$previewImageUrl' },
        deadline: { $last: '$deadline' },
        name: { $last: '$name' },
        description: { $last: '$description' },
        price: { $last: '$price' },
        listedAt: { $last: '$listedAt' },
        isListedOnce: { $last: '$isListedOnce' },
        bid: { $last: '$bid' },
        likes: { $last: '$likes' },
        views: { $last: '$views' },
      },
    },

    {
      $lookup: {
        from: 'users',
        localField: 'ownerAddress',
        foreignField: 'publicAddress',
        as: 'owner',
      },
    },
  ]);
  return nfts;
};

const getHotAuctions = async (): Promise<any> => {
  const nfts: any = Nft.aggregate([
    {
      $group: {
        _id: { tokenId: '$tokenId', nftAddress: '$nftAddress', ownerAddress: '$ownerAddress' },
        mongoId: { $last: '$_id' },
        createdAt: { $last: '$createdAt' },
        tokenId: { $last: '$tokenId' },
        expirationDate: { $last: '$expirationDate' },
        creatorAddress: { $last: '$creatorAddress' },
        ownerAddress: { $last: '$ownerAddress' },
        nftAddress: { $last: '$nftAddress' },
        multiple: { $last: '$multiple' },
        collectionId: { $last: '$collectionId' },
        totalAmount: { $last: '$totalAmount' },
        leftAmount: { $last: '$leftAmount' },
        listedAmount: { $last: '$listedAmount' },
        category: { $last: '$category' },
        royalty: { $last: '$royalty' },
        marketType: { $last: '$marketType' },
        status: { $last: '$status' },
        imageUrl: { $last: '$imageUrl' },
        previewImageUrl: { $last: '$previewImageUrl' },
        listingId: { $last: '$listingId' },
        deadline: { $last: '$deadline' },
        name: { $last: '$name' },
        description: { $last: '$description' },
        price: { $last: '$price' },
        networkId: { $last: '$networkId' },
        minimumBid: { $min: '$minimumBid' },
        listedAt: { $last: '$listedAt' },
        isListedOnce: { $last: '$isListedOnce' },
      },
    },
    {
      $lookup: {
        from: 'users',
        localField: 'ownerAddress',
        foreignField: 'publicAddress',
        as: 'owner',
      },
    },
    {
      $lookup: {
        from: 'nftcollections',
        localField: 'collectionId',
        foreignField: 'id',
        as: 'nftCollection',
      },
    },
    {
      $lookup: {
        from: 'bids',
        localField: 'listingId',
        foreignField: 'listingId',
        as: 'bids',
      },
    },
    {
      $addFields: {
        expirationTime: {
          $dateDiff: {
            startDate: new Date(),
            endDate: '$expirationDate',
            unit: 'millisecond',
          },
        },
        totalBid: {
          $reduce: {
            input: '$bids',
            initialValue: 0,
            in: {
              $add: [{ $toDouble: '$$this.price' }, '$$value'],
            },
          },
        },
      },
    },
    {
      $match: {
        marketType: 'AUCTION',
        status: 'ON_SELL',
        expirationTime: { $gt: 0 },
      },
    },
    {
      $sort: {
        totalBid: -1,
        createdAt: -1,
      },
    },
    {
      $limit: 10,
    },
  ]);
  return nfts;
};

const getNftCountByCategory = async (): Promise<any> => {
  const nfts: any = Nft.aggregate([
    {
      $group: {
        _id: { tokenId: '$tokenId', nftAddress: '$nftAddress', ownerAddress: '$ownerAddress' },
        category: { $last: '$category' },
        status: { $last: '$status' },
      },
    },
    {
      $match: { status: STATUS.ON_SELL },
    },
    {
      $group: {
        _id: {
          category: '$category',
        },
        name: { $last: '$category' },
        count: { $sum: 1 },
      },
    },
  ]);

  return nfts;
};

// const setMarketContractId = async (data: { mongoId: string, marketContractId: string }): Promise<any> => {
//   const { mongoId, marketContractId } = data;

//   const updatedNft = {
//     marketContractId,
//     status: STATUS.ON_SELL
//   };

//   const nft = await Nft.findByIdAndUpdate(
//     mongoId,
//     updatedNft,
//     { new: true }
//   );
//   if (!nft) {
//     throw new Error(`not nft with id ${mongoId}`);
//   }
//   return nft;

// };

const getNftByTransactionHashAndFlag = async (data: { transactionHash: string; flag: boolean }): Promise<INft> => {
  const { transactionHash, flag } = data;
  const bid: any = await Nft.findOne({ transactionHash, flag }).populate('buyer').sort({ createdAt: -1 });
  return bid;
};

const nftService = {
  createNft,
  updateNft,
  getNftByTransactionHash,
  getNftByTransactionHashAndFlag,
  // sellNft,
  // updateNft,
  getNftList,
  getNfts,
  // getCollectibleNfts,
  getMyNfts,
  getNftDetailes,
  nftMultipleDetailes,
  getNftHistory,
  // getAuctionNfts,
  // getNftByTokenAndOwnerAddress,
  getNftsByCollectionId,
  getHotAuctions,
  getNftCountByCategory,
  getNftDetailesNoPopulate,
  // setMarketContractId,
};

export default nftService;
