import { query } from 'express-validator';
import { getNftsValidator } from '../../nfts/v1/nftValidators_v1';

export const globalSearchValidator = [
  query('q', 'Query is not valid').isString(),
  query('limit', 'Limit is not valid').isInt({ max: 3 }).toInt(),
];

export const searchCollectionsValidator = [
  query('q', 'Query is not valid').isString(),
  query('currentPage', 'Current Page is not valid').isInt({ min: 0 }).toInt(),
  query('pageLimit', 'Page Size is not valid').isInt({ min: 1 }).toInt(),
];

export const searchNftsValidator = [
  query('q', 'Query is not valid').isString(),
  ...getNftsValidator,
];

export const searchUsersValidator = [
  query('q', 'Query is not valid').isString(),
  query('currentPage', 'Current Page is not valid').isInt({ min: 0 }).toInt(),
  query('pageLimit', 'Page Size is not valid').isInt({ min: 1 }).toInt(),
];