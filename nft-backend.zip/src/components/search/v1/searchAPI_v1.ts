import express from 'express';
import { validate } from '../../../middleware/validators';
import { search, searchCollections, searchNfts, searchUsers } from './searchController_v1';
import { globalSearchValidator, searchCollectionsValidator, searchNftsValidator, searchUsersValidator } from './searchValidators_v1';
const router = express.Router();

router.get('/',
  globalSearchValidator,
  validate,
  search,
);
router.get('/collection',
  searchCollectionsValidator,
  validate,
  searchCollections,
);
router.get('/nft',
  searchNftsValidator,
  validate,
  searchNfts,
);
router.get('/user',
  searchUsersValidator,
  validate,
  searchUsers,
);

export default router;