import { RequestHandler } from 'express';
import { FilterOperator } from '../../../types/nfts.types';
import logger from '../../../utils/logger';
import collectionService from '../../collections/v1/collectionsService_v1';
import nftService from '../../nfts/v1/nftService_v1';
import userService from '../../users/v1/usersService_v1';

const empty = { data: [], pagination: { totalCount: 0 } };

export const search: RequestHandler = async (req, res, next): Promise<void> => {
  const { q, limit } = req.query;

  try {
    const _match = q as string;
    const _limit = limit as unknown as number;
    const nftQuery = {
      search: _match,
      pageLimit: _limit,
      currentPage: 0,
      filters: [{
        left: 'status',
        op: FilterOperator.Equals,
        right: 'ON_SELL',
      }],
    };

    const collections = await collectionService.searchCollections(_match, _limit);
    const nfts = await nftService.getNftList(nftQuery);
    const users = await userService.searchUsers(_match, _limit);

    res.send({
      collections: collections.length ? collections[0].data : [],
      nfts: nfts.length ? nfts[0].data : [],
      users: users.length ? users[0].data : [],
    });
  } catch (error) {
    logger.error('error in search', error);
    next(error);
  }
};

export const searchCollections: RequestHandler = async (req, res, next): Promise<void> => {
  const { q, currentPage, pageLimit } = req.query;

  try {
    const _match = q as string;
    const _currentPage = Number.parseInt(currentPage as string);
    const _pageLimit = Number.parseInt(pageLimit as string);

    let result = await collectionService.searchCollections(_match, _pageLimit, _currentPage);

    result = result?.length ? result[0] : empty;
    res.send(result);
  } catch (error) {
    logger.error('error in searchCollections', error);
    next(error);
  }
};

export const searchNfts: RequestHandler = async (req, res, next): Promise<void> => {
  const { q } = req.query;

  try {
    const match = q as string;

    let result = await nftService.getNftList({ ...req.query, search: match });

    result = result?.length ? result[0] : empty;
    res.send(result);
  } catch (error) {
    logger.error('error in searchNfts', error);
    next(error);
  }
};

export const searchUsers: RequestHandler = async (req, res, next): Promise<void> => {
  const { q, currentPage, pageLimit } = req.query;

  try {
    const match = q as string;
    const _currentPage = Number.parseInt(currentPage as string);
    const _pageLimit = Number.parseInt(pageLimit as string);

    let result = await userService.searchUsers(match, _pageLimit, _currentPage);

    result = result?.length ? result[0] : empty;
    res.send(result);
  } catch (error) {
    logger.error('error in searchUsers', error);
    next(error);
  }
};
