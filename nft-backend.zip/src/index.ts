import express, { Application, Request, Response } from 'express';

import routes from './startup/routes';
import mongodb from './startup/mongodb';
import prod from './startup/prod';
import dev from './startup/dev';
import logger from './utils/logger';
// import config from 'config';
// eslint-disable-next-line import/first
import 'dotenv/config';
// import { init3 } from './utils/web3';
import { init31 } from './utils/web31';

init31();

const app: Application = express();
const port = process.env.PORT || 3033;

app.get('/', (req: Request, res: Response) => {
  res.send('You are in server');
});


prod(app);
dev(app);
routes(app);
mongodb();
// logger example
logger.info('logger example');
//config example
// logger.info(config.get('db'));
// console.log('config.get(db)', config.get('db'));


app.listen(port, () => logger.info(`Listening on port ${port}...`));
