import jwt, { TokenExpiredError } from 'jsonwebtoken';
import config from 'config';
import { ERRORS } from '../utils/enums';

const secret = process.env.secret || (config.get('secret') as string);

function auth(req: any, res: any, next: any) {
  const token = req.header('Authorization');
  if (!token) return res.status(403).send(ERRORS.NO_TOKEN);

  console.log('🚀 ~ file: auth.ts ~ line 9 ~ auth ~ token', token);

  try {
    const decoded = jwt.verify(token, secret);

    req.user = decoded;
    next();
  } catch (err) {
    console.log('🚀 ~ file: auth.ts ~ line 19 ~ auth ~ err', err);
    if (err instanceof TokenExpiredError) {
      return res.status(401).send(ERRORS.TOKEN_EXPIRED);
    }
    res.status(401).send(ERRORS.TOKEN_INVALID);
  }
}

export default auth;
