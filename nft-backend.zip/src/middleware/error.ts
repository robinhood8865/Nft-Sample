import {
  Request,
  Response,
  // NextFunction,
} from 'express';
import { GeneralError } from '../utils/errors';

const handleErrors = (
  err: any,
  req: Request,
  res: Response,
  // next: NextFunction,
) => {
  console.log('🚀 ~ file: error.ts ~ handleErrors ~ line 14 ~ err', err);

  if (err instanceof GeneralError) {
    return res.json({
      status: 404,
      message: err.message,
    });
  }

  return res.status(500).json({
    status: 'error',
    message: err,
  });
};

export default handleErrors;
