import { validationResult } from 'express-validator';
import { Request, Response, NextFunction } from 'express';
import { GeneralError } from '../utils/errors';
// import { Logform } from 'winston';

export const validate = (req: Request, res: Response, next: NextFunction): void => {
  const errors: any = validationResult(req);
  if (errors.isEmpty()) {
    return next();
  }
  console.log('🚀 ~ file: validators.ts ~ line 8 ~ validate ~ errors', errors);

  throw new GeneralError(`${errors.errors[0].msg} in ${errors.errors[0].param}`);
};
