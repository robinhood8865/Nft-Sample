import multer from 'multer';

const upload = multer({
  limits: {
    fileSize: 1000000,
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|png|JPG|JPEG|PNG)$/)) {
      // @ts-ignore
      return cb(new Error('please upload an image'), false);
    }

    req.file = file;
    cb(null, true);
  },
});

export default upload;
