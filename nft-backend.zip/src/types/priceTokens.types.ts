export interface IPriceToken {
  _id: string;
  name: string;
  address: string;
}
