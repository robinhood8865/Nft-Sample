

export interface ICollection {
    _id: string,
    name: string;
    description: string;
    userAddress: string;
}

