

// import { SIDE } from '../../src/enums';

export interface IUser {
    _id?: number;
    nonce?: number;
    publicAddress: string;
    firstName: string;
    lastName: string;
    username: string;
    profileImage: string;
    bannerImage?: string;
    bio?: string,
    twitter?: string,
    youtube?: string,
    discord?: string,
    facebook?: string,
    ticktok?: string,
    snapchat?: string,
    website?: string,
}