

// import { SIDE } from '../../src/enums';

import { IUser } from "./users.types";
export interface IBid {
    transactionHash: string;
    price: number;
    buyerAddress: string;
    listingId: string;
    tokenId: string;
    networkId: number;
    nftAddress: string;
    createdAt?: Date;
    updatedAt?: Date;
    buyer?: IUser[];
}

