// import { SIDE } from '../../src/enums';

import { MARKET_TYPE } from '../utils/enums';
import { IUser } from './users.types';
import { IPriceToken } from './priceTokens.types';

export interface INftAttribute {
  trait_type: string;
  value: string | number;
  display_type?: string;
}

export interface INft {
  _id: string;
  tokenId: string;
  listingId: string;
  marketContractId: string;
  name: string;
  royalty: number;
  description: string;
  imageUrl: string;
  previewImageUrl: string;
  attributes: INftAttribute[];
  marketType: MARKET_TYPE;
  creatorAddress: string;
  ownerAddress: string;
  nftAddress: string;
  category: string;
  status: string;
  item_type: string;
  collectionId: string;
  multiple: boolean;
  deadline: string;
  amountLeft: number;
  initialAmount: number;
  nftLink: string;
  bidLink: string;
  authorImg: string;
  price: string;
  bid: string;
  likes: number;
  isListedOnce: boolean;
  minimumBid: string;
  pricetokentype: string;
  priceToken: IPriceToken;
  startingDate: Date;
  expirationDate: Date;
  users: IUser[];
  creator: IUser[];
  owner: IUser[];
  totalAmount: number;
  leftAmount: number;
  listedAmount: number;
}

export enum FilterOperator {
  Equals = 'eq',
  GreaterThanEqual = 'gte',
  Contains = 'contains',
  LessThanEqual = 'lte',
  InArray = 'in',
}

export interface INftFilter {
  left: string;
  op: FilterOperator;
  right: number | string;
}
