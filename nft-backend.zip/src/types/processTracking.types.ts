import { ICollection } from './collections.types';
import { IUser } from './users.types';
import { PROCESS_TRAKING_ACTION, PROCESS_TRAKING_STATUS } from './../utils/enums';

export interface IProcessTracking {
  action: PROCESS_TRAKING_ACTION;
  processStatus: PROCESS_TRAKING_STATUS;
  listingId: string;
  userAddress: string;
  price: number;
  tokenId: string;
  // hash: string,
  transactionHash?: string;
  networkId: number;
  status?: string;
  name?: string;
  id?: string;
  description?: string;
  imageUrl?: string;
  user?: string;
  creatorAddress?: string;
  ownerAddress?: string;
  nftAddress?: string;
  minimumBid?: string;
  startingDate?: Date;
  collectionId?: string;
  creator?: IUser[];
  nftCollection?: ICollection[];
}

export interface TrackingServiceFuncProps {
  processStatus?: PROCESS_TRAKING_STATUS;
  actions?: PROCESS_TRAKING_ACTION[];
  limit?: number;
  date: Date;
}
