

// import { SIDE } from '../../src/enums';

export interface IAuction {
    sellerAddress: string;
    marketItemId: string;
    tokenId: string;
    expiredTime: string;
    initialPrice: string;
    buyNowPrice: string;
}

