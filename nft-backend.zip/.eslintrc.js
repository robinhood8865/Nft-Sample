module.exports = {
  parser: '@typescript-eslint/parser', // Specifies the ESLint parser
  parserOptions: {
    ecmaVersion: 2020, // Allows for the parsing of modern ECMAScript features
    sourceType: 'module', // Allows for the use of imports
  },
  plugins: [
    "security",
    "import",
  ],
  extends: [
    'plugin:@typescript-eslint/recommended', // Uses the recommended rules from the @typescript-eslint/eslint-plugin
    // *** security ***
    "plugin:security/recommended",
    // "tslint-config-security", / NOTE: doesn't work' eslint will be down' 
    "plugin:import/errors",
    "plugin:import/warnings",
    "plugin:import/typescript",
    // *** if we would like prettier ***
    // 'prettier/@typescript-eslint', // Uses eslint-config-prettier to disable ESLint rules from @typescript-eslint/eslint-plugin that would conflict with prettier
    // 'plugin:prettier/recommended', // Enables eslint-plugin-prettier and eslint-config-prettier. This will display prettier errors as ESLint errors. Make sure this is always the last configuration in the extends array.
  ],
  rules: {
    // *** if we would like prettier ***
    // Place to specify ESLint rules. Can be used to overwrite rules specified from the extended configs
    // e.g. "@typescript-eslint/explicit-function-return-type": "off",
    // 'prettier/prettier': [
    //   'error',
    //   {
    //     endOfLine: 'auto',
    //   },
    // ],
    // semi: 2,
    "@typescript-eslint/explicit-module-boundary-types": "off",
    "@typescript-eslint/ban-ts-comment": "off",
    "@typescript-eslint/no-var-requires": 1,
    "@typescript-eslint/no-explicit-any": "off",
    'import/first': ['error', 'absolute-first'],
    'import/no-mutable-exports': 'error',
    'import/no-absolute-path': 'error',
    "semi": [
      "error",
      "always",
    ],
    "camelcase": 0,
    "comma-dangle": ["error", "always-multiline"],
    "indent": [
      "error",
      2,
    ],
    "prefer-const": [
      "error",
      {
        "destructuring": "any",
        "ignoreReadBeforeAssign": false,
      },
    ],
  },
};


// add import/first