

####
heroku login
####
deploy to heroku
git push heroku main

d
###
run the project
npm run dev